import React, { useState, useEffect } from 'react';
import { Leaf, Navigation, MapPin, Sparkles, CheckCircle, Search, Bus, Train, Bike, Car, Plane, AlertCircle, Fuel, Trees, Thermometer, ShoppingBag, Ship, ExternalLink, Share2, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const FACTORS = {
  pesawat: 0.255,
  kereta: 0.035,
  mobil: 0.165,
  motor: 0.103,
  bus: 0.089,
  ferry: 0.19
};

const ISLAND_MAP: Record<string, string> = {
  // JAWA
  Jakarta: 'jawa', Bogor: 'jawa', Depok: 'jawa',
  Bandung: 'jawa', Cirebon: 'jawa', Semarang: 'jawa',
  Solo: 'jawa', Yogyakarta: 'jawa', Surabaya: 'jawa',
  Malang: 'jawa', Madiun: 'jawa', Kediri: 'jawa',
  Blitar: 'jawa', Jember: 'jawa', Banyuwangi: 'jawa',
  Tegal: 'jawa', Purwokerto: 'jawa', Serang: 'jawa',
  Tangerang: 'jawa', Bekasi: 'jawa', Bojonegoro: 'jawa',
  Sidoarjo: 'jawa', Mojokerto: 'jawa', Pasuruan: 'jawa',
  Probolinggo: 'jawa', Tulungagung: 'jawa',
  
  // SUMATERA
  Medan: 'sumatera', Pekanbaru: 'sumatera', Padang: 'sumatera',
  Palembang: 'sumatera', Banda_Aceh: 'sumatera', Jambi: 'sumatera',
  Bengkulu: 'sumatera', Lampung: 'sumatera', Batam: 'batam',
  Dumai: 'sumatera', Bangkinang: 'sumatera', Duri: 'sumatera',
  Kandis: 'sumatera', Bukittinggi: 'sumatera', Solok: 'sumatera',
  Payakumbuh: 'sumatera', Binjai: 'sumatera', Sibolga: 'sumatera',
  Lubuklinggau: 'sumatera', Prabumulih: 'sumatera',
  Lhokseumawe: 'sumatera', Langsa: 'sumatera',
  'Tanjung Pinang': 'bintan',
  Bangka: 'bangka', 'Pangkal Pinang': 'bangka', Muntok: 'bangka',
  Belitung: 'belitung', 'Tanjung Pandan': 'belitung',

  // KALIMANTAN
  Balikpapan: 'kalimantan', Samarinda: 'kalimantan',
  Banjarmasin: 'kalimantan', Pontianak: 'kalimantan',
  Palangkaraya: 'kalimantan', Tarakan: 'kalimantan',
  Bontang: 'kalimantan', Singkawang: 'kalimantan',

  // SULAWESI
  Makassar: 'sulawesi', Manado: 'sulawesi', Palu: 'sulawesi',
  Kendari: 'sulawesi', Gorontalo: 'sulawesi', Parepare: 'sulawesi',
  Palopo: 'sulawesi', Bitung: 'sulawesi',

  // BALI & NUSA TENGGARA
  Denpasar: 'bali', Gilimanuk: 'bali', Padangbai: 'bali',
  Mataram: 'lombok', Lembar: 'lombok', Kayangan: 'lombok',
  Bima: 'sumbawa', 'Sumbawa Besar': 'sumbawa', Dompu: 'sumbawa', 'Poto Tano': 'sumbawa',
  Kupang: 'timor', Maumere: 'flores', Ende: 'flores',
  Labuan_Bajo: 'flores',

  // MADURA
  Kamal: 'madura',

  // PAPUA & MALUKU
  Jayapura: 'papua', Sorong: 'papua_barat', Manokwari: 'papua_barat',
  Merauke: 'papua', Ambon: 'maluku', Ternate: 'maluku_utara',
};

const FERRY_ROUTES: Record<string, {
  port_origin: string,
  port_origin_coord: { lat: number, lon: number },
  port_dest: string,
  port_dest_coord: { lat: number, lon: number },
  distance_km: number
}> = {

  // =====================
  // JAWA ↔ SUMATERA
  // =====================
  'jawa-sumatera': {
    port_origin: 'Pelabuhan Merak',
    port_origin_coord: { lat: -5.929, lon: 105.999 },
    port_dest: 'Pelabuhan Bakauheni',
    port_dest_coord: { lat: -5.869, lon: 105.732 },
    distance_km: 26
  },
  'sumatera-jawa': {
    port_origin: 'Pelabuhan Bakauheni',
    port_origin_coord: { lat: -5.869, lon: 105.732 },
    port_dest: 'Pelabuhan Merak',
    port_dest_coord: { lat: -5.929, lon: 105.999 },
    distance_km: 26
  },

  // =====================
  // JAWA ↔ BALI
  // =====================
  'jawa-bali': {
    port_origin: 'Pelabuhan Ketapang',
    port_origin_coord: { lat: -8.158, lon: 114.383 },
    port_dest: 'Pelabuhan Gilimanuk',
    port_dest_coord: { lat: -8.168, lon: 114.443 },
    distance_km: 4
  },
  'bali-jawa': {
    port_origin: 'Pelabuhan Gilimanuk',
    port_origin_coord: { lat: -8.168, lon: 114.443 },
    port_dest: 'Pelabuhan Ketapang',
    port_dest_coord: { lat: -8.158, lon: 114.383 },
    distance_km: 4
  },

  // =====================
  // BALI ↔ LOMBOK
  // =====================
  'bali-lombok': {
    port_origin: 'Pelabuhan Padangbai',
    port_origin_coord: { lat: -8.533, lon: 115.509 },
    port_dest: 'Pelabuhan Lembar',
    port_dest_coord: { lat: -8.720, lon: 116.075 },
    distance_km: 40
  },
  'lombok-bali': {
    port_origin: 'Pelabuhan Lembar',
    port_origin_coord: { lat: -8.720, lon: 116.075 },
    port_dest: 'Pelabuhan Padangbai',
    port_dest_coord: { lat: -8.533, lon: 115.509 },
    distance_km: 40
  },

  // =====================
  // LOMBOK ↔ SUMBAWA
  // =====================
  'lombok-sumbawa': {
    port_origin: 'Pelabuhan Kayangan',
    port_origin_coord: { lat: -8.617, lon: 116.467 },
    port_dest: 'Pelabuhan Poto Tano',
    port_dest_coord: { lat: -8.580, lon: 116.979 },
    distance_km: 35
  },
  'sumbawa-lombok': {
    port_origin: 'Pelabuhan Poto Tano',
    port_origin_coord: { lat: -8.580, lon: 116.979 },
    port_dest: 'Pelabuhan Kayangan',
    port_dest_coord: { lat: -8.617, lon: 116.467 },
    distance_km: 35
  },

  // =====================
  // JAWA ↔ KALIMANTAN
  // (Ro-Ro swasta: Dharma Lautan, Tanto, dll)
  // =====================
  'jawa-kalimantan': {
    port_origin: 'Pelabuhan Tanjung Perak',
    port_origin_coord: { lat: -7.194, lon: 112.731 },
    port_dest: 'Pelabuhan Trisakti',
    port_dest_coord: { lat: -3.320, lon: 114.590 },
    distance_km: 280
  },
  'kalimantan-jawa': {
    port_origin: 'Pelabuhan Trisakti',
    port_origin_coord: { lat: -3.320, lon: 114.590 },
    port_dest: 'Pelabuhan Tanjung Perak',
    port_dest_coord: { lat: -7.194, lon: 112.731 },
    distance_km: 280
  },

  // =====================
  // JAWA ↔ SULAWESI
  // (Ro-Ro swasta: Dharma Lautan, dll)
  // =====================
  'jawa-sulawesi': {
    port_origin: 'Pelabuhan Tanjung Perak',
    port_origin_coord: { lat: -7.194, lon: 112.731 },
    port_dest: 'Pelabuhan Makassar',
    port_dest_coord: { lat: -5.136, lon: 119.412 },
    distance_km: 850
  },
  'sulawesi-jawa': {
    port_origin: 'Pelabuhan Makassar',
    port_origin_coord: { lat: -5.136, lon: 119.412 },
    port_dest: 'Pelabuhan Tanjung Perak',
    port_dest_coord: { lat: -7.194, lon: 112.731 },
    distance_km: 850
  },

  // =====================
  // SUMATERA ↔ BATAM/KEPRI
  // (Ro-Ro via Tanjung Buton)
  // =====================
  'sumatera-batam': {
    port_origin: 'Pelabuhan Tanjung Buton',
    port_origin_coord: { lat: 1.061, lon: 102.627 },
    port_dest: 'Pelabuhan Telaga Punggur',
    port_dest_coord: { lat: 1.131, lon: 104.014 },
    distance_km: 85
  },
  'batam-sumatera': {
    port_origin: 'Pelabuhan Telaga Punggur',
    port_origin_coord: { lat: 1.131, lon: 104.014 },
    port_dest: 'Pelabuhan Tanjung Buton',
    port_dest_coord: { lat: 1.061, lon: 102.627 },
    distance_km: 85
  },

  // =====================
  // SUMATERA ↔ BATAM
  // (via Dumai — Ro-Ro swasta)
  // =====================
  'sumatera-batam-dumai': {
    port_origin: 'Pelabuhan Dumai',
    port_origin_coord: { lat: 1.672, lon: 101.448 },
    port_dest: 'Pelabuhan Sekupang',
    port_dest_coord: { lat: 1.117, lon: 103.897 },
    distance_km: 120
  },
  'batam-sumatera-dumai': {
    port_origin: 'Pelabuhan Sekupang',
    port_origin_coord: { lat: 1.117, lon: 103.897 },
    port_dest: 'Pelabuhan Dumai',
    port_dest_coord: { lat: 1.672, lon: 101.448 },
    distance_km: 120
  },

  // =====================
  // KALIMANTAN ↔ SULAWESI
  // (Ro-Ro swasta via Balikpapan-Pare Pare)
  // =====================
  'kalimantan-sulawesi': {
    port_origin: 'Pelabuhan Semayang',
    port_origin_coord: { lat: -1.268, lon: 116.830 },
    port_dest: 'Pelabuhan Pare-Pare',
    port_dest_coord: { lat: -4.013, lon: 119.623 },
    distance_km: 400
  },
  'sulawesi-kalimantan': {
    port_origin: 'Pelabuhan Pare-Pare',
    port_origin_coord: { lat: -4.013, lon: 119.623 },
    port_dest: 'Pelabuhan Semayang',
    port_dest_coord: { lat: -1.268, lon: 116.830 },
    distance_km: 400
  },



  // =====================
  // SUMATERA ↔ BANGKA BELITUNG
  // (Ro-Ro reguler)
  // =====================
  'sumatera-bangka': {
    port_origin: 'Pelabuhan Tanjung Api-Api',
    port_origin_coord: { lat: -2.746, lon: 104.685 },
    port_dest: 'Pelabuhan Muntok',
    port_dest_coord: { lat: -2.066, lon: 105.173 },
    distance_km: 70
  },
  'bangka-sumatera': {
    port_origin: 'Pelabuhan Muntok',
    port_origin_coord: { lat: -2.066, lon: 105.173 },
    port_dest: 'Pelabuhan Tanjung Api-Api',
    port_dest_coord: { lat: -2.746, lon: 104.685 },
    distance_km: 70
  },

  // =====================
  // SUMATERA ↔ BANGKA (via Palembang-Pangkalbalam)
  // =====================
  'sumatera-bangka-2': {
    port_origin: 'Pelabuhan Boom Baru',
    port_origin_coord: { lat: -2.991, lon: 104.763 },
    port_dest: 'Pelabuhan Pangkalbalam',
    port_dest_coord: { lat: -2.108, lon: 106.114 },
    distance_km: 130
  },
  'bangka-sumatera-2': {
    port_origin: 'Pelabuhan Pangkalbalam',
    port_origin_coord: { lat: -2.108, lon: 106.114 },
    port_dest: 'Pelabuhan Boom Baru',
    port_dest_coord: { lat: -2.991, lon: 104.763 },
    distance_km: 130
  },
};

const AIRPORT_COORDS: Record<string, {
  airport_name: string,
  coord: { lat: number, lon: number }
}> = {
  'Jakarta':     { airport_name: 'Bandara Soekarno-Hatta',
                   coord: { lat: -6.126, lon: 106.656 } },
  'Surabaya':    { airport_name: 'Bandara Juanda',
                   coord: { lat: -7.380, lon: 112.787 } },
  'Medan':       { airport_name: 'Bandara Kualanamu',
                   coord: { lat: 3.642, lon: 98.885 } },
  'Makassar':    { airport_name: 'Bandara Sultan Hasanuddin',
                   coord: { lat: -5.062, lon: 119.554 } },
  'Balikpapan':  { airport_name: 'Bandara Sultan Aji Muhammad Sulaiman',
                   coord: { lat: -1.268, lon: 116.894 } },
  'Denpasar':    { airport_name: 'Bandara Ngurah Rai',
                   coord: { lat: -8.748, lon: 115.167 } },
  'Pekanbaru':   { airport_name: 'Bandara Sultan Syarif Kasim II',
                   coord: { lat: 0.461, lon: 101.445 } },
  'Padang':      { airport_name: 'Bandara Minangkabau',
                   coord: { lat: -0.787, lon: 100.281 } },
  'Palembang':   { airport_name: 'Bandara Sultan Mahmud Badaruddin II',
                   coord: { lat: -2.898, lon: 104.699 } },
  'Semarang':    { airport_name: 'Bandara Ahmad Yani',
                   coord: { lat: -6.971, lon: 110.375 } },
  'Yogyakarta':  { airport_name: 'Bandara YIA',
                   coord: { lat: -7.902, lon: 110.057 } },
  'Solo':        { airport_name: 'Bandara Adi Soemarmo',
                   coord: { lat: -7.516, lon: 110.757 } },
  'Malang':      { airport_name: 'Bandara Abdul Rachman Saleh',
                   coord: { lat: -7.927, lon: 112.714 } },
  'Bandung':     { airport_name: 'Bandara Husein Sastranegara',
                   coord: { lat: -6.901, lon: 107.576 } },
  'Pontianak':   { airport_name: 'Bandara Supadio',
                   coord: { lat: -0.150, lon: 109.404 } },
  'Banjarmasin': { airport_name: 'Bandara Syamsudin Noor',
                   coord: { lat: -3.442, lon: 114.763 } },
  'Manado':      { airport_name: 'Bandara Sam Ratulangi',
                   coord: { lat: 1.549, lon: 124.926 } },
  'Jayapura':    { airport_name: 'Bandara Sentani',
                   coord: { lat: -2.577, lon: 140.516 } },
  'Ambon':       { airport_name: 'Bandara Pattimura',
                   coord: { lat: -3.710, lon: 128.089 } },
  'Kupang':      { airport_name: 'Bandara El Tari',
                   coord: { lat: -10.172, lon: 123.671 } },
  'Mataram':     { airport_name: 'Bandara Lombok',
                   coord: { lat: -8.757, lon: 116.276 } },
  'Batam':       { airport_name: 'Bandara Hang Nadim',
                   coord: { lat: 1.121, lon: 104.119 } },
  'Jambi':       { airport_name: 'Bandara Sultan Thaha',
                   coord: { lat: -1.638, lon: 103.644 } },
  'Bengkulu':    { airport_name: 'Bandara Fatmawati Soekarno',
                   coord: { lat: -3.864, lon: 102.339 } },
  'Tarakan':     { airport_name: 'Bandara Juwata',
                   coord: { lat: 3.327, lon: 117.569 } },
  'Palu':        { airport_name: 'Bandara Mutiara Sis Al-Jufrie',
                   coord: { lat: -0.918, lon: 119.910 } },
  'Kendari':     { airport_name: 'Bandara Haluoleo',
                   coord: { lat: -4.081, lon: 122.418 } },
  'Gorontalo':   { airport_name: 'Bandara Djalaluddin',
                   coord: { lat: 0.638, lon: 122.850 } },
  'Labuan Bajo': { airport_name: 'Bandara Komodo',
                   coord: { lat: -8.487, lon: 119.889 } },
  'Bima':        { airport_name: 'Bandara Sultan Muhammad Salahuddin',
                   coord: { lat: -8.540, lon: 118.687 } },
  'Maumere':     { airport_name: 'Bandara Frans Seda',
                   coord: { lat: -8.633, lon: 122.237 } },
  'Sorong':      { airport_name: 'Bandara Domine Eduard Osok',
                   coord: { lat: -0.894, lon: 131.287 } },
  'Manokwari':   { airport_name: 'Bandara Rendani',
                   coord: { lat: -0.892, lon: 134.049 } },
  'Merauke':     { airport_name: 'Bandara Mopah',
                   coord: { lat: -8.520, lon: 140.418 } },
  'Ternate':     { airport_name: 'Bandara Sultan Babullah',
                   coord: { lat: 0.831, lon: 127.381 } },
  'Banda Aceh':  { airport_name: 'Bandara Sultan Iskandar Muda',
                   coord: { lat: 5.523, lon: 95.420 } },
  'Banyuwangi':  { airport_name: 'Bandara Banyuwangi',
                   coord: { lat: -8.316, lon: 114.340 } },
};

const NEAREST_AIRPORT: Record<string, {
  airport_city: string,
  airport_name: string,
  airport_coord: { lat: number, lon: number }
}> = {
  // Jawa Tengah & sekitar
  'Tegal':       { airport_city: 'Semarang', 
                   airport_name: 'Bandara Ahmad Yani',
                   airport_coord: { lat: -6.971, lon: 110.375 } },
  'Purwokerto':  { airport_city: 'Semarang',
                   airport_name: 'Bandara Ahmad Yani', 
                   airport_coord: { lat: -6.971, lon: 110.375 } },
  'Pekalongan':  { airport_city: 'Semarang',
                   airport_name: 'Bandara Ahmad Yani',
                   airport_coord: { lat: -6.971, lon: 110.375 } },
  'Magelang':    { airport_city: 'Yogyakarta',
                   airport_name: 'Bandara YIA',
                   airport_coord: { lat: -7.902, lon: 110.057 } },
  'Kebumen':     { airport_city: 'Yogyakarta',
                   airport_name: 'Bandara YIA',
                   airport_coord: { lat: -7.902, lon: 110.057 } },

  // Jawa Timur
  'Kediri':      { airport_city: 'Malang',
                   airport_name: 'Bandara Abdul Rachman Saleh',
                   airport_coord: { lat: -7.927, lon: 112.714 } },
  'Blitar':      { airport_city: 'Malang',
                   airport_name: 'Bandara Abdul Rachman Saleh',
                   airport_coord: { lat: -7.927, lon: 112.714 } },
  'Tulungagung': { airport_city: 'Malang',
                   airport_name: 'Bandara Abdul Rachman Saleh',
                   airport_coord: { lat: -7.927, lon: 112.714 } },
  'Jombang':     { airport_city: 'Surabaya',
                   airport_name: 'Bandara Juanda',
                   airport_coord: { lat: -7.380, lon: 112.787 } },
  'Mojokerto':   { airport_city: 'Surabaya',
                   airport_name: 'Bandara Juanda',
                   airport_coord: { lat: -7.380, lon: 112.787 } },
  'Sidoarjo':    { airport_city: 'Surabaya',
                   airport_name: 'Bandara Juanda',
                   airport_coord: { lat: -7.380, lon: 112.787 } },
  'Bojonegoro':  { airport_city: 'Surabaya',
                   airport_name: 'Bandara Juanda',
                   airport_coord: { lat: -7.380, lon: 112.787 } },
  'Madiun':      { airport_city: 'Solo',
                   airport_name: 'Bandara Adi Soemarmo',
                   airport_coord: { lat: -7.516, lon: 110.757 } },
  'Ngawi':       { airport_city: 'Solo',
                   airport_name: 'Bandara Adi Soemarmo',
                   airport_coord: { lat: -7.516, lon: 110.757 } },

  // Jawa Barat
  'Bogor':       { airport_city: 'Jakarta',
                   airport_name: 'Bandara Soekarno-Hatta',
                   airport_coord: { lat: -6.126, lon: 106.656 } },
  'Depok':       { airport_city: 'Jakarta',
                   airport_name: 'Bandara Soekarno-Hatta',
                   airport_coord: { lat: -6.126, lon: 106.656 } },
  'Bekasi':      { airport_city: 'Jakarta',
                   airport_name: 'Bandara Soekarno-Hatta',
                   airport_coord: { lat: -6.126, lon: 106.656 } },
  'Karawang':    { airport_city: 'Jakarta',
                   airport_name: 'Bandara Soekarno-Hatta',
                   airport_coord: { lat: -6.126, lon: 106.656 } },
  'Sukabumi':    { airport_city: 'Bandung',
                   airport_name: 'Bandara Husein Sastranegara',
                   airport_coord: { lat: -6.901, lon: 107.576 } },
  'Tasikmalaya': { airport_city: 'Bandung',
                   airport_name: 'Bandara Husein Sastranegara',
                   airport_coord: { lat: -6.901, lon: 107.576 } },
  'Cirebon':     { airport_city: 'Bandung',
                   airport_name: 'Bandara Husein Sastranegara',
                   airport_coord: { lat: -6.901, lon: 107.576 } },

  // Sumatera
  'Bangkinang':  { airport_city: 'Pekanbaru',
                   airport_name: 'Bandara Sultan Syarif Kasim II',
                   airport_coord: { lat: 0.461, lon: 101.445 } },
  'Kandis':      { airport_city: 'Pekanbaru',
                   airport_name: 'Bandara Sultan Syarif Kasim II',
                   airport_coord: { lat: 0.461, lon: 101.445 } },
  'Duri':        { airport_city: 'Pekanbaru',
                   airport_name: 'Bandara Sultan Syarif Kasim II',
                   airport_coord: { lat: 0.461, lon: 101.445 } },
  'Bukittinggi': { airport_city: 'Padang',
                   airport_name: 'Bandara Minangkabau',
                   airport_coord: { lat: -0.787, lon: 100.281 } },
  'Payakumbuh':  { airport_city: 'Padang',
                   airport_name: 'Bandara Minangkabau',
                   airport_coord: { lat: -0.787, lon: 100.281 } },
  'Solok':       { airport_city: 'Padang',
                   airport_name: 'Bandara Minangkabau',
                   airport_coord: { lat: -0.787, lon: 100.281 } },
  'Binjai':      { airport_city: 'Medan',
                   airport_name: 'Bandara Kualanamu',
                   airport_coord: { lat: 3.642, lon: 98.885 } },
  'Pematangsiantar': { airport_city: 'Medan',
                   airport_name: 'Bandara Kualanamu',
                   airport_coord: { lat: 3.642, lon: 98.885 } },
  'Lubuklinggau':{ airport_city: 'Palembang',
                   airport_name: 'Bandara Sultan Mahmud Badaruddin II',
                   airport_coord: { lat: -2.898, lon: 104.699 } },
  'Prabumulih':  { airport_city: 'Palembang',
                   airport_name: 'Bandara Sultan Mahmud Badaruddin II',
                   airport_coord: { lat: -2.898, lon: 104.699 } },
};

const KAI_NETWORK_CITIES = [
  // JAWA & BALI
  "Jakarta", "Bogor", "Depok", "Tangerang", "Bekasi", "Bandung", "Cirebon",
  "Semarang", "Solo", "Yogyakarta", "Surabaya", "Malang", "Madiun", "Kediri",
  "Blitar", "Jombang", "Mojokerto", "Probolinggo", "Pasuruan", "Jember",
  "Banyuwangi", "Purwokerto", "Kutoarjo", "Kebumen", "Kroya", "Tegal",
  "Pekalongan", "Cepu", "Bojonegoro", "Lamongan", "Sidoarjo", "Tulungagung",
  "Nganjuk", "Kertosono",
  // SUMATERA
  "Medan", "Binjai", "Tebing Tinggi", "Pematangsiantar", "Kisaran",
  "Rantauprapat", "Tanjungbalai", "Padang", "Pariaman", "Padang Panjang",
  "Bukittinggi", "Payakumbuh", "Solok", "Sawahlunto",
  "Palembang", "Prabumulih", "Lahat", "Lubuklinggau", "Muara Enim",
  "Lampung", "Kotabumi", "Metro", "Kertapati",
  // SULAWESI
  "Makassar", "Barru", "Pangkajene", "Maros"
];

interface Coordinates {
  lat: string;
  lon: string;
  name: string;
}

interface MapLeg {
  from: { lat: number, lon: number, name: string },
  to: { lat: number, lon: number, name: string },
  mode: 'darat' | 'feri' | 'pesawat',
  emission: number,
  geometry?: [number, number][]  // koordinat rute dari OSRM
}

async function getRouteGeometry(
  from: { lat: number, lon: number },
  to: { lat: number, lon: number }
): Promise<[number, number][]> {
  try {
    const url = `https://router.project-osrm.org/route/v1/driving/` +
      `${from.lon},${from.lat};${to.lon},${to.lat}` +
      `?overview=full&geometries=geojson`;
    
    const res = await fetch(url);
    const data = await res.json();
    
    if (data.code !== 'Ok' || !data.routes?.[0]) {
      // Fallback ke garis lurus kalau OSRM gagal
      return [[from.lat, from.lon], [to.lat, to.lon]];
    }
    
    // OSRM return coordinates sebagai [lon, lat]
    // Leaflet butuh [lat, lon] — perlu di-swap
    const coords = data.routes[0].geometry.coordinates;
    return coords.map(([lon, lat]: [number, number]) => 
      [lat, lon] as [number, number]
    );
  } catch {
    // Fallback ke garis lurus
    return [[from.lat, from.lon], [to.lat, to.lon]];
  }
}

function ApiStatusBadge({ status, lang, t }: { status: 'connected' | 'fact_mode' | 'unavailable', lang: 'en' | 'id', t: any }) {
  const apiStatus = status;
  return (
    <div className="flex items-center">
      {apiStatus === 'connected' && (
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400"/>
          <span className="text-[9px] uppercase tracking-widest text-emerald-400">
            {t.apiConnected}
          </span>
        </div>
      )}

      {apiStatus === 'fact_mode' && (
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-amber-400"/>
          <span className="text-[9px] uppercase tracking-widest text-amber-400">
            {lang === 'en' ? 'Fact Mode' : 'Mode Fakta'}
          </span>
        </div>
      )}

      {apiStatus === 'unavailable' && (
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-red-400"/>
          <span className="text-[9px] uppercase tracking-widest text-red-400">
            {t.apiDisconnected}
          </span>
        </div>
      )}
    </div>
  );
}

function MapView({ legs, visible, t }: { 
  legs: MapLeg[], 
  visible: boolean,
  t: any
}) {
  const mapRef = React.useRef<HTMLDivElement>(null);
  const mapInstanceRef = React.useRef<any>(null);

  React.useEffect(() => {
    if (!visible || !mapRef.current || legs.length === 0) return;
    
    // Destroy existing map instance
    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
    }

    // Init map
    const L = (window as any).L;
    if (!L) return;

    const map = L.map(mapRef.current, {
      zoomControl: true,
      scrollWheelZoom: false, // disable scroll zoom
      attributionControl: false
    });

    // Tile layer — pakai CartoDB Positron 
    // (clean, cocok sama aesthetic TripTrace)
    L.tileLayer(
      'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
      { subdomains: 'abcd', maxZoom: 19 }
    ).addTo(map);

    const allPoints: [number, number][] = [];

    legs.forEach((leg, index) => {
      const fromLatLng: [number, number] = [leg.from.lat, leg.from.lon];
      const toLatLng: [number, number] = [leg.to.lat, leg.to.lon];

      allPoints.push(fromLatLng, toLatLng);

      // Warna garis berdasarkan moda:
      const colors = {
        darat: '#1D9E75', // hijau brand
        feri: '#3B82F6', // biru
        pesawat: '#8B5CF6' // ungu
      };
      const color = colors[leg.mode] || '#1D9E75';

      // Style garis berdasarkan moda:
      if (leg.mode === 'darat' && leg.geometry && leg.geometry.length > 2) {
        // Pakai geometri jalan dari OSRM
        L.polyline(leg.geometry, {
          color,
          weight: 3,
          opacity: 0.9
        }).addTo(map);
      } else if (leg.mode === 'feri') {
        // Feri: garis putus-putus lurus
        L.polyline([fromLatLng, toLatLng], {
          color,
          weight: 3,
          dashArray: '8, 8',
          opacity: 0.8
        }).addTo(map);
      } else if (leg.mode === 'pesawat') {
        // Pesawat: kurva melengkung
        const midLat = (leg.from.lat + leg.to.lat) / 2 - Math.abs(leg.from.lon - leg.to.lon) * 0.15;
        const midLon = (leg.from.lon + leg.to.lon) / 2;
        
        // Buat kurva dengan banyak titik interpolasi
        const curvePoints: [number, number][] = [];
        for (let t = 0; t <= 1; t += 0.02) {
          const lat = (1-t)*(1-t)*leg.from.lat + 
                      2*(1-t)*t*midLat + 
                      t*t*leg.to.lat;
          const lon = (1-t)*(1-t)*leg.from.lon + 
                      2*(1-t)*t*midLon + 
                      t*t*leg.to.lon;
          curvePoints.push([lat, lon]);
        }
        
        L.polyline(curvePoints, {
          color,
          weight: 2,
          dashArray: '4, 6',
          opacity: 0.7
        }).addTo(map);
      } else {
        // Fallback garis lurus
        L.polyline([fromLatLng, toLatLng], {
          color,
          weight: 3,
          opacity: 0.9
        }).addTo(map);
      }

      const createMarker = (
        latlng: [number, number], 
        label: string, 
        isStart: boolean
      ) => {
        const html = `
          <div style="
            background: ${isStart ? '#1D9E75' : '#EF4444'};
            color: white;
            border-radius: 50%;
            width: 28px;
            height: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 700;
            border: 2px solid white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            font-family: Inter, sans-serif;
          ">${isStart ? 'A' : 'B'}</div>
        `;
        const icon = L.divIcon({ 
          html, 
          className: '', 
          iconSize: [28, 28],
          iconAnchor: [14, 14]
        });
        return L.marker(latlng, { icon })
          .bindPopup(`
            <div style="font-family:Inter,sans-serif; 
                        font-size:12px; padding:4px;">
              <strong>${label}</strong>
            </div>
          `);
      };

      if (index === 0) {
        createMarker(fromLatLng, leg.from.name, true).addTo(map);
      }
      if (index === legs.length - 1) {
        createMarker(toLatLng, leg.to.name, false).addTo(map);
      } else {
        const transitHtml = `
          <div style="
            background: white;
            border: 2px solid #94A3B8;
            border-radius: 50%;
            width: 10px;
            height: 10px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
          "></div>
        `;
        const transitIcon = L.divIcon({ 
          html: transitHtml, 
          className: '',
          iconSize: [10, 10],
          iconAnchor: [5, 5]
        });
        L.marker(toLatLng, { icon: transitIcon })
          .bindPopup(`
            <div style="font-family:Inter,sans-serif;
                        font-size:11px; padding:4px;
                        color:#64748B;">
              ${leg.to.name}
            </div>
          `)
          .addTo(map);
      }
    });

    if (allPoints.length > 0) {
      map.fitBounds(allPoints, { padding: [30, 30] });
    }

    mapInstanceRef.current = map;

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [legs, visible]);

  return (
    <div 
      ref={mapRef} 
      className="w-full h-64 lg:h-80 rounded-2xl overflow-hidden border border-slate-200"
      style={{ zIndex: 0 }}
    />
  );
}

function EduPage({ onBack, lang, t }: { onBack: () => void, lang: 'en' | 'id', t: any, key?: React.Key }) {
  return (
    <div className="min-h-screen bg-editorial-bg">
      
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white 
                      border-b border-slate-100">
        <div className="max-w-3xl mx-auto px-6 py-4 
                        flex items-center gap-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 
                       hover:opacity-70 transition-opacity cursor-pointer">
            <Leaf className="w-5 h-5 text-brand-green" />
            <span className="font-bold text-brand-green">
              TripTrace
            </span>
          </button>
        </div>
      </nav>

      {/* Content */}
      <div className="max-w-3xl mx-auto px-6 py-12">
        
        {/* Hero section */}
        <div className="mb-16">
          <p className="text-[11px] uppercase tracking-widest 
                        text-brand-green font-medium mb-4">
            {lang === 'en' ? 'Education' : 'Edukasi'}
          </p>
          <h1 className="text-4xl md:text-5xl font-serif 
                         italic text-slate-800 leading-tight mb-6">
            {t.eduHero}
          </h1>
          <p className="text-slate-500 text-base leading-relaxed 
                        max-w-xl">
            {t.eduSub}
          </p>
        </div>

        {/* Section 1: Definisi Jejak Karbon */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 rounded-full bg-emerald-100 
                            flex items-center justify-center">
              <span className="text-emerald-600 text-sm">01</span>
            </div>
            <h2 className="text-xl font-semibold text-slate-800">
              {lang === 'en' ? 'What is Carbon Footprint?' : 'Apa itu Jejak Karbon?'}
            </h2>
          </div>
          
          <div className="prose prose-slate max-w-none">
            {lang === 'en' ? (
              <>
                <p className="text-slate-600 leading-relaxed mb-4">
                  <strong className="text-slate-800">
                    Carbon footprint
                  </strong> is the total amount of greenhouse gases 
                  produced by human activities, organizations, or products — measured in units of 
                  <strong className="text-slate-800"> CO₂e 
                  (carbon dioxide equivalent)</strong>.
                </p>
                <p className="text-slate-600 leading-relaxed mb-4">
                  Every time you use a motorized vehicle, 
                  turn on an AC, or even order food online, 
                  there are carbon emissions produced behind it. 
                  Travel is one of the largest contributors 
                  to a person's personal carbon footprint.
                </p>
              </>
            ) : (
              <>
                <p className="text-slate-600 leading-relaxed mb-4">
                  <strong className="text-slate-800">
                    Jejak karbon (carbon footprint)
                  </strong> adalah total jumlah gas rumah kaca 
                  yang dihasilkan oleh aktivitas seseorang, 
                  organisasi, atau produk — diukur dalam satuan 
                  <strong className="text-slate-800"> CO₂e 
                  (karbon dioksida ekuivalen)</strong>.
                </p>
                <p className="text-slate-600 leading-relaxed mb-4">
                  Setiap kali kamu naik kendaraan bermotor, 
                  menyalakan AC, atau bahkan memesan makanan online, 
                  ada emisi karbon yang dihasilkan di baliknya. 
                  Perjalanan adalah salah satu kontributor terbesar 
                  jejak karbon pribadi seseorang.
                </p>
              </>
            )}
            
            {/* Callout box */}
            <div className="bg-emerald-50 border-l-2 
                            border-emerald-400 rounded-r-xl 
                            p-5 my-6">
              <p className="text-emerald-800 text-sm 
                            leading-relaxed">
                {lang === 'en' ? (
                  <>
                    🌍 The average Indonesian produces about 
                    <strong> 2.1 tons of CO₂e per year</strong> — 
                    well below the global average of 4.7 tons. 
                    But as the economy and mobility grow, 
                    this figure continues to rise.
                  </>
                ) : (
                  <>
                    🌍 Rata-rata orang Indonesia menghasilkan sekitar 
                    <strong> 2.1 ton CO₂e per tahun</strong> — 
                    jauh di bawah rata-rata global 4,7 ton. 
                    Tapi seiring pertumbuhan ekonomi dan mobilitas, 
                    angka ini terus naik.
                  </>
                )}
              </p>
            </div>
          </div>
        </section>

        {/* Section 2: Transportasi & Emisi */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 rounded-full bg-blue-100 
                            flex items-center justify-center">
              <span className="text-blue-600 text-sm">02</span>
            </div>
            <h2 className="text-xl font-semibold text-slate-800">
              {lang === 'en' ? 'Why is Transportation a Big Issue?' : 'Kenapa Transportasi Jadi Masalah Besar?'}
            </h2>
          </div>

          <p className="text-slate-600 leading-relaxed mb-6">
            {lang === 'en' ? (
              <>
                The transportation sector accounts for about 
                <strong className="text-slate-800"> 16% of total 
                global greenhouse gas emissions</strong> — and in 
                Indonesia, this number continues to increase along with 
                the growth of private vehicle ownership.
              </>
            ) : (
              <>
                Sektor transportasi menyumbang sekitar 
                <strong className="text-slate-800"> 16% dari total 
                emisi gas rumah kaca global</strong> — dan di 
                Indonesia, angka ini terus meningkat seiring 
                pertumbuhan kepemilikan kendaraan pribadi.
              </>
            )}
          </p>

          {/* Comparison cards moda */}
          <p className="text-sm font-medium text-slate-700 mb-3">
            {lang === 'en' ? 'Emission comparison per km per passenger:' : 'Perbandingan emisi per km per penumpang:'}
          </p>
          <div className="space-y-3 mb-6">
            {[
              { mode: lang === 'en' ? '✈ Airplane' : '✈ Pesawat', val: 255, color: 'bg-red-400' },
              { mode: lang === 'en' ? '🚗 Private Car (1 pax)' : '🚗 Mobil Pribadi (1 org)', val: 165, color: 'bg-orange-400' },
              { mode: lang === 'en' ? '🏍 Motorcycle' : '🏍 Motor', val: 103, color: 'bg-yellow-400' },
              { mode: lang === 'en' ? '🚌 Bus' : '🚌 Bus', val: 89, color: 'bg-blue-400' },
              { mode: lang === 'en' ? '🚂 Train' : '🚂 Kereta Api', val: 35, color: 'bg-emerald-400' },
            ].map(item => (
              <div key={item.mode} 
                   className="flex items-center gap-3">
                <span className="text-sm text-slate-600 w-48 
                                 shrink-0">
                  {item.mode}
                </span>
                <div className="flex-1 bg-slate-100 
                                rounded-full h-2 overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${item.color}`}
                    style={{ width: `${(item.val/255)*100}%` }}
                  />
                </div>
                <span className="text-xs text-slate-500 
                                 w-20 text-right shrink-0">
                  {item.val} g/km
                </span>
              </div>
            ))}
          </div>

          <div className="bg-amber-50 border-l-2 border-amber-400 
                          rounded-r-xl p-5">
            <p className="text-amber-800 text-sm leading-relaxed">
              {lang === 'en' ? (
                <>
                  🚂 Taking a train produces emissions 
                  <strong> 7x lower </strong> 
                  than a plane for the same distance. 
                  Choosing your transport mode is one of the 
                  biggest climate decisions you can make.
                </>
              ) : (
                <>
                  🚂 Naik kereta api menghasilkan emisi 
                  <strong> 7x lebih rendah </strong> 
                  dibanding pesawat untuk jarak yang sama. 
                  Pilihan moda transportasi adalah salah satu 
                  keputusan iklim terbesar yang bisa kamu buat.
                </>
              )}
            </p>
          </div>
        </section>

        {/* Section 3: Glosarium */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 rounded-full bg-violet-100 
                            flex items-center justify-center">
              <span className="text-violet-600 text-sm">03</span>
            </div>
            <h2 className="text-xl font-semibold text-slate-800">
              {lang === 'en' ? 'Terms You Should Know' : 'Istilah yang Perlu Kamu Tahu'}
            </h2>
          </div>

          <div className="space-y-4">
            {(lang === 'en' ? [
              {
                term: 'CO₂e (Carbon Dioxide Equivalent)',
                def: 'A standard unit to measure carbon footprint. All greenhouse gases (CO₂, methane, nitrous oxide, etc.) are converted into "CO₂ equivalents" based on their global warming potential. So 1 kg of CO₂e could mean 1 kg of pure CO₂, or a smaller amount of a much more potent gas.'
              },
              {
                term: 'Emission',
                def: 'Greenhouse gases released into the atmosphere as a result of human activities. In the context of transportation, emissions are primarily CO₂ from burning fossil fuels (gasoline, diesel, jet fuel).'
              },
              {
                term: 'Carbon Offset',
                def: 'A way to "compensate" for emissions that have already been produced, by funding projects that absorb or prevent emissions elsewhere — such as tree planting, renewable energy, or forest conservation.'
              },
              {
                term: 'Greenhouse Gases (GHG)',
                def: 'Gases in the atmosphere that trap heat from the sun, causing the greenhouse effect and global warming. The most common: CO₂ (carbon dioxide), CH₄ (methane), and N₂O (nitrous oxide).'
              },
              {
                term: 'Emission Factor',
                def: 'A number that shows how many kg of CO₂e are produced per unit of activity — for example per km of travel, per liter of fuel, or per kWh of electricity. TripTrace uses emission factors from DEFRA 2024.'
              },
            ] : [
              {
                term: 'CO₂e (Karbon Dioksida Ekuivalen)',
                def: 'Satuan standar untuk mengukur jejak karbon. Semua gas rumah kaca (CO₂, metana, nitrogen oksida, dll) dikonversi ke "ekuivalen CO₂" berdasarkan potensi pemanasan globalnya. Jadi 1 kg CO₂e bisa berarti 1 kg CO₂ murni, atau sejumlah kecil gas yang lebih kuat.'
              },
              {
                term: 'Emisi',
                def: 'Gas rumah kaca yang dilepaskan ke atmosfer sebagai hasil aktivitas manusia. Dalam konteks transportasi, emisi utamanya adalah CO₂ dari pembakaran bahan bakar fosil (bensin, solar, avtur).'
              },
              {
                term: 'Carbon Offset (Kompensasi Karbon)',
                def: 'Cara untuk "menebus" emisi yang sudah terlanjur dihasilkan, dengan mendanai proyek yang menyerap atau mencegah emisi di tempat lain — seperti penanaman pohon, energi terbarukan, atau konservasi hutan.'
              },
              {
                term: 'Gas Rumah Kaca (GRK)',
                def: 'Gas di atmosfer yang memerangkap panas dari matahari, menyebabkan efek rumah kaca dan pemanasan global. Yang paling umum: CO₂ (karbon dioksida), CH₄ (metana), dan N₂O (nitrous oxide).'
              },
              {
                term: 'Faktor Emisi',
                def: 'Angka yang menunjukkan berapa kg CO₂e yang dihasilkan per satuan aktivitas — misalnya per km perjalanan, per liter bahan bakar, atau per kWh listrik. TripTrace menggunakan faktor emisi dari DEFRA 2024.'
              },
            ]).map(item => (
              <div key={item.term}
                   className="border border-slate-200 
                              rounded-xl p-5">
                <h3 className="font-semibold text-slate-800 
                               text-sm mb-2">
                  {item.term}
                </h3>
                <p className="text-slate-500 text-sm 
                               leading-relaxed">
                  {item.def}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Section 4: Tentang DEFRA */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 rounded-full bg-slate-100 
                            flex items-center justify-center">
              <span className="text-slate-600 text-sm">04</span>
            </div>
            <h2 className="text-xl font-semibold text-slate-800">
              {lang === 'en' ? 'What is DEFRA and How is it Calculated?' : 'Apa itu DEFRA dan Bagaimana Cara Hitungnya?'}
            </h2>
          </div>

          <p className="text-slate-600 leading-relaxed mb-4">
            <strong className="text-slate-800">DEFRA</strong>
            {' '}{lang === 'en' ? 'stands for' : 'adalah singkatan dari'}{' '}
            <em> Department for Environment, Food & Rural 
            Affairs</em>
            {' '}{lang === 'en' ? '— the environmental ministry of the UK Government. Every year, DEFRA publishes' : '— kementerian lingkungan hidup Pemerintah Inggris. Setiap tahun, DEFRA menerbitkan'}
            {' '}<strong className="text-slate-800"> {lang === 'en' ? 'official emission factor tables' : 'tabel faktor emisi resmi'}</strong>{' '}
            {lang === 'en' ? 'used by companies, researchers, and applications worldwide to calculate carbon footprints consistently.' : 'yang digunakan oleh perusahaan, peneliti, dan aplikasi di seluruh dunia untuk menghitung jejak karbon secara konsisten.'}
          </p>

          <p className="text-slate-600 leading-relaxed mb-6">
            {lang === 'en' ? (
              <>
                Although published by a UK agency, the methodology is internationally recognized and widely used outside the UK — including for calculating vehicle emissions based on fuel type and vehicle type.
              </>
            ) : (
              <>
                Meski diterbitkan oleh lembaga Inggris, 
                metodologinya diakui secara internasional dan 
                banyak dipakai di luar UK — termasuk untuk 
                perhitungan emisi kendaraan berdasarkan jenis 
                bahan bakar dan tipe kendaraan.
              </>
            )}
          </p>

          {/* Cara hitung */}
          <div className="bg-slate-50 rounded-2xl p-6 mb-6">
            <p className="text-sm font-semibold text-slate-700 
                          mb-4">
              {lang === 'en' ? 'How TripTrace calculates your emissions:' : 'Cara TripTrace menghitung emisimu:'}
            </p>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <span className="text-brand-green font-bold 
                                 text-sm mt-0.5">1</span>
                <p className="text-sm text-slate-600">
                  <strong>{lang === 'en' ? 'Calculate route distance' : 'Hitung jarak rute'}</strong> — 
                  {lang === 'en' ? 'using OSRM (Open Source Routing Machine) based on OpenStreetMap data. For planes, Haversine distance is used × 1.1 for route correction.' : 'menggunakan OSRM (Open Source Routing Machine) yang berbasis data OpenStreetMap. Untuk pesawat, digunakan jarak lurus (Haversine) × 1.1 untuk koreksi rute.'}
                </p>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-brand-green font-bold 
                                 text-sm mt-0.5">2</span>
                <p className="text-sm text-slate-600">
                  <strong>{lang === 'en' ? 'Multiply by DEFRA emission factor' : 'Kalikan dengan faktor emisi DEFRA'}</strong> — 
                  {lang === 'en' ? 'each mode has a different factor (kg CO₂e per km per passenger).' : 'setiap moda punya faktor berbeda (kg CO₂e per km per penumpang).'}
                </p>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-brand-green font-bold 
                                 text-sm mt-0.5">3</span>
                <p className="text-sm text-slate-600">
                  <strong>{lang === 'en' ? 'For multi-mode trips' : 'Untuk perjalanan multi-moda'}</strong> — 
                  {lang === 'en' ? 'emissions from each leg are calculated separately and then summed.' : 'emisi setiap leg dihitung terpisah lalu dijumlahkan.'}
                </p>
              </div>
            </div>

            {/* Formula visual */}
            <div className="mt-5 bg-white border border-slate-200 
                            rounded-xl p-4 text-center">
              <p className="text-xs text-slate-400 mb-2">
                {lang === 'en' ? 'Basic formula' : 'Formula dasar'}
              </p>
              <p className="font-mono text-sm text-slate-700">
                {lang === 'en' ? 'Emission (kg CO₂e) = Distance (km) × Emission Factor (kg CO₂e/km)' : 'Emisi (kg CO₂e) = Jarak (km) × Faktor Emisi (kg CO₂e/km)'}
              </p>
            </div>
          </div>

          <div className="bg-slate-100 rounded-xl p-4">
            <p className="text-xs text-slate-500 leading-relaxed">
              {lang === 'en' ? (
                <>
                  📄 Data source: DEFRA Greenhouse Gas Reporting — 
                  Conversion Factors 2024. This document is publicly available 
                  on the official UK government website (gov.uk). Factors used by TripTrace: 
                  Train 0.035 · Bus 0.089 · Motorcycle 0.103 · 
                  Car 0.165 · Airplane 0.255 kg CO₂e/km.
                </>
              ) : (
                <>
                  📄 Sumber data: DEFRA Greenhouse Gas Reporting — 
                  Conversion Factors 2024. Dokumen ini tersedia 
                  publik di situs resmi pemerintah Inggris 
                  (gov.uk). Faktor yang digunakan TripTrace: 
                  Kereta 0.035 · Bus 0.089 · Motor 0.103 · 
                  Mobil 0.165 · Pesawat 0.255 kg CO₂e/km.
                </>
              )}
            </p>
          </div>
        </section>

        {/* CTA kembali ke app */}
        <div className="text-center py-8 border-t 
                        border-slate-100">
          <p className="text-slate-500 text-sm mb-4">
            {lang === 'en' ? 'Now you understand the context.' : 'Sekarang kamu sudah paham konteksnya.'}
          </p>
          <button
            onClick={onBack}
            className="bg-brand-green text-white px-8 py-3 
                       rounded-full font-bold text-sm 
                       hover:bg-opacity-90 transition">
            {t.heroCTA} →
          </button>
        </div>

      </div>
    </div>
  );
}

function HomePage({ onStart, onEdu, lang, setLang, t }: { onStart: () => void, onEdu: () => void, lang: 'en' | 'id', setLang: (l: 'en' | 'id') => void, t: any, key?: React.Key }) {
  return (
    <motion.div
      key="homepage"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4 }}
      className="min-h-screen flex flex-col bg-editorial-bg overflow-hidden font-sans"
    >
      {/* Navbar */}
      <nav className="h-14 border-b border-slate-100 flex items-center justify-between px-4 md:px-8 shrink-0 bg-white">
        <div className="flex items-center gap-2">
          <Leaf className="w-6 h-6 text-brand-green" />
          <span className="text-xl font-bold text-brand-green">TripTrace</span>
        </div>
        <div className="flex items-center gap-6">
          <button
            onClick={onEdu}
            className="text-xs text-slate-400 hover:text-slate-600 transition-colors"
          >
            {t.aboutCarbon}
          </button>
          
          <button
            onClick={() => setLang(lang === 'en' ? 'id' : 'en')}
            className="flex items-center gap-1.5 text-xs 
                       border border-slate-200 rounded-full 
                       px-3 py-1.5 text-slate-500 
                       hover:border-slate-400 transition-colors">
            <span>{lang === 'en' ? '🇮🇩' : '🇬🇧'}</span>
            <span>{lang === 'en' ? 'ID' : 'EN'}</span>
          </button>

          <button 
            onClick={onStart}
            className="px-3 py-1.5 border border-brand-green text-brand-green rounded-full text-xs font-bold hover:bg-brand-green hover:text-white transition-all active:scale-95"
          >
            {t.startCalculating}
          </button>
        </div>
      </nav>

      {/* Hero */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12 text-center">
        <div className="flex flex-col items-center mb-10">
          <p className="text-[9px] md:text-[11px] uppercase tracking-wider md:tracking-widest text-slate-400 font-bold mb-2 px-4 text-center">{t.heroStat}</p>
          <h1 className="text-[72px] md:text-[120px] font-serif font-bold leading-none text-brand-green tracking-tighter">92 kg</h1>
          <p className="text-xl md:text-2xl text-slate-400 italic font-serif mt-2">{t.heroUnit}</p>
        </div>

        <div className="mt-2 text-center px-6">
          <h2 className="text-xl md:text-4xl font-serif italic text-slate-800 leading-tight">{t.heroTagline}</h2>
          <p className="text-sm md:text-base text-slate-500 mt-4 max-w-md mx-auto leading-relaxed">
            {t.heroSub}
          </p>
        </div>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onStart}
          className="mt-8 bg-brand-green text-white px-10 py-3.5 rounded-xl font-semibold text-sm tracking-wide hover:bg-opacity-90 transition-all shadow-sm hover:shadow-md flex items-center justify-center gap-2"
        >
          {t.heroCTA}
        </motion.button>
      </div>

      {/* Stats */}
      <div className="shrink-0 pb-8">
        <div className="flex items-center justify-center gap-0 mt-10">
          {/* Stat 1 */}
          <div className="flex flex-col items-center px-8">
            <span className="text-2xl font-bold text-slate-800">5</span>
            <span className="text-[10px] uppercase tracking-widest text-slate-400 mt-1">{t.statModes}</span>
          </div>

          {/* Divider */}
          <div className="w-px h-8 bg-slate-200"/>

          {/* Stat 2 */}
          <div className="flex flex-col items-center px-8">
            <span className="text-2xl font-bold text-slate-800">Indonesia</span>
            <span className="text-[10px] uppercase tracking-widest text-slate-400 mt-1">{t.statCoverage}</span>
          </div>

          {/* Divider */}
          <div className="w-px h-8 bg-slate-200"/>

          {/* Stat 3 */}
          <div className="flex flex-col items-center px-8">
            <span className="text-2xl font-bold text-slate-800">DEFRA</span>
            <span className="text-[10px] uppercase tracking-widest text-slate-400 mt-1">{t.statStandard}</span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="shrink-0 py-4">
        <p className="text-center text-[10px] text-slate-300 italic">
          {t.footerNote}
        </p>
      </footer>
    </motion.div>
  );
}

function ComparisonCard({ icon, label, value, unit, context, framing }: { icon: React.ReactNode, label: string, value: string | number, unit: string, context: string, framing?: string }) {
  return (
    <div className="p-4 lg:p-6 glass-card rounded-2xl shadow-sm flex flex-col items-start text-left overflow-hidden h-full">
      <div className="mb-3 p-2 bg-slate-50 rounded-lg shrink-0">
        {icon}
      </div>
      <p className="text-[9px] uppercase font-bold text-slate-400 mb-1 tracking-[0.1em] leading-tight">{label}</p>
      {framing && (
        <p className="text-[9px] italic text-slate-400 mb-2 max-w-full line-clamp-1 overflow-hidden">{framing}</p>
      )}
      <div className="flex items-baseline gap-1.5 shrink-0">
        <p className="text-2xl lg:text-3xl font-bold text-slate-800 leading-none shrink-0">{value}</p>
        <p className="text-[9px] font-bold text-slate-400 uppercase leading-none">{unit}</p>
      </div>
      <p className="text-[9px] text-slate-400 mt-2 italic font-medium leading-tight whitespace-pre-line line-clamp-2 overflow-hidden">
        {context}
      </p>
    </div>
  );
}

const T = {
  en: {
    // Navbar & Header
    appTagline: 'Measure your trace, choose your path.',
    aboutCarbon: 'About Carbon',
    startCalculating: 'Start Calculating',
    apiConnected: 'API Connected',
    apiDisconnected: 'API Unavailable',
    factMode: 'Fact Mode',

    // Homepage
    heroStat: 'A single domestic flight produces',
    heroUnit: 'CO₂e per passenger',
    heroTagline: 'Measure your footprint before you go.',
    heroSub: "For those who travel between cities — and are starting to think about the impact.",
    heroCTA: 'Check Your Carbon Footprint',
    statModes: 'Transport Modes',
    statCoverage: 'Coverage',
    statStandard: 'Emission Standard',

    // Form
    tripDetails: 'Trip Details',
    originCity: 'Origin City',
    destCity: 'Destination City',
    transport: 'Transport Mode',
    passengers: 'Passengers',
    calculate: 'CALCULATE',
    calculating: 'Calculating...',
    findingRoute: 'Finding Route...',

    // Transport modes
    plane: 'Airplane',
    train: 'Train',
    car: 'Private Car',
    motorcycle: 'Motorcycle',
    bus: 'Bus',

    // Results
    totalCarbon: 'Total Carbon Footprint',
    tripRoute: 'ROUTE',
    tripDetails2: 'TRIP BREAKDOWN',
    totalEmission: 'TOTAL EMISSION',
    routeViz: 'Route Visualization',
    mapLegendLand: 'Land',
    mapLegendFerry: 'Ferry',
    mapLegendFlight: 'Flight',

    // Comparison cards
    fuelCard: 'FUEL EQUIVALENT',
    fuelSub: 'Equivalent to filling a motorcycle tank',
    fuelContext: 'Enough for a motorcycle to travel',
    treeCard: 'TREE ABSORPTION TIME',
    treeSub: 'Time needed for 1 tree to absorb this',
    treeContext1: 'Or',
    treeContext2: 'trees needed to absorb in 1 year',
    plasticCard: 'PLASTIC BAGS',
    plasticSub: 'Equivalent plastic bags produced',
    plasticContext: 'Equivalent to single-use plastic bag production',

    // AI Insight
    aiInsight: 'Gemini AI Insight',
    altPrefix: 'Alternative',
    altSuffix: 'for This Route',
    share: 'Share',
    save: 'Save',
    readMore: 'Read more',
    close: 'Close',

    // Next step card
    greenerOption: 'There\'s a greener option 🌿',
    bestChoice: 'Best choice! 🎉',
    alreadyBest: 'You\'ve chosen the lowest emission mode for this route. Thank you for caring.',
    trainCTA: 'Find Train Schedule →',
    busCTA: 'Ask AI for Bus Route →',
    seeAbove: '💡 See route suggestion above',

    // Comparison table
    efficiency: 'EFFICIENCY ALTERNATIVES',
    yourChoice: 'YOUR CHOICE',
    bestMode: 'BEST CHOICE 🌿',
    routeUnavailable: 'Route unavailable',
    greenest: 'Greenest',

    // KAI Warning
    kaiWarning: 'may not be directly served by KAI. Emission estimate is still calculated as reference, but please check schedule availability at kai.id before departure.',

    // Kereta hypothetical
    ifRouteExisted: 'This train route does not exist yet.',

    // Footer
    footerNote: 'Emission factors based on DEFRA Greenhouse Gas Reporting 2024. Distance calculated via OSRM routing engine. · Data not stored.',

    // Mobile collapsed bar
    changeRoute: 'Change Route',

    // Status
    sessionStatus: 'SESSION STATUS',

    // Save file
    saveTitle: 'TRIPTRACE - CARBON FOOTPRINT REPORT',
    saveDate: 'Date',
    saveRoute: 'Route',
    saveDistance: 'Distance',
    saveMode: 'Mode',
    saveEmission: 'Emission',
    saveComparison: 'All modes comparison',
    saveAI: 'AI Recommendation',
    saveFooter: 'Emission data based on DEFRA 2024.',

    // Edu page
    eduTitle: 'About Carbon',
    eduHero: 'Why does your travel carbon footprint matter?',
    eduSub: 'Before you calculate your emissions, it helps to understand what we\'re actually measuring — and why it matters for our planet.',
  },
  id: {
    // Navbar & Header
    appTagline: 'Ukur jejakmu, pilih jalurmu.',
    aboutCarbon: 'Tentang Karbon',
    startCalculating: 'Mulai Hitung',
    apiConnected: 'API Terkoneksi',
    apiDisconnected: 'API Tidak Tersedia',
    factMode: 'Mode Fakta',

    // Homepage
    heroStat: 'Sekali terbang Jakarta–Surabaya menghasilkan',
    heroUnit: 'CO₂e per penumpang',
    heroTagline: 'Ukur jejakmu sebelum berangkat.',
    heroSub: 'Buat kamu yang sering mudik, business trip, atau solo traveling — dan mulai mikirin dampaknya.',
    heroCTA: 'Cek Jejak Karbonmu',
    statModes: 'Moda Transportasi',
    statCoverage: 'Jangkauan Wilayah',
    statStandard: 'Standar Emisi 2024',

    // Form
    tripDetails: 'Rincian Perjalanan',
    originCity: 'Kota Asal',
    destCity: 'Kota Tujuan',
    transport: 'Moda Transportasi',
    passengers: 'Penumpang',
    calculate: 'KALKULASI',
    calculating: 'Menghitung...',
    findingRoute: 'Mencari Rute...',

    // Transport modes
    plane: 'Pesawat',
    train: 'Kereta Api',
    car: 'Mobil Pribadi',
    motorcycle: 'Motor',
    bus: 'Bus',

    // Results
    totalCarbon: 'Total Jejak Karbon',
    tripRoute: 'RUTE',
    tripDetails2: 'RINCIAN PERJALANAN',
    totalEmission: 'TOTAL EMISI',
    routeViz: 'Visualisasi Rute',
    mapLegendLand: 'Darat',
    mapLegendFerry: 'Feri',
    mapLegendFlight: 'Pesawat',

    // Comparison cards
    fuelCard: 'ISI BENSIN MOTOR',
    fuelSub: 'Setara mengisi penuh tangki motor',
    fuelContext: 'Cukup untuk motor keliling',
    treeCard: 'WAKTU POHON MENYERAP',
    treeSub: 'Butuh waktu selama ini bagi 1 pohon',
    treeContext1: 'Atau butuh',
    treeContext2: 'pohon untuk serap dalam setahun',
    plasticCard: 'KANTONG PLASTIK',
    plasticSub: 'Sebanyak ini kantong plastik diproduksi',
    plasticContext: 'Setara produksi kantong plastik sekali pakai',

    // AI Insight
    aiInsight: 'Insight Gemini AI',
    altPrefix: 'Alternatif',
    altSuffix: 'untuk Rute Ini',
    share: 'Bagikan',
    save: 'Simpan',
    readMore: 'Baca selengkapnya',
    close: 'Tutup',

    // Next step card
    greenerOption: 'Ada pilihan lebih hijau 🌿',
    bestChoice: 'Pilihan terbaikmu! 🎉',
    alreadyBest: 'Kamu sudah memilih moda dengan emisi terendah untuk rute ini. Terima kasih sudah peduli.',
    trainCTA: 'Cari Jadwal Kereta →',
    busCTA: 'Tanya Rute Bus ke AI →',
    seeAbove: '💡 Lihat saran rute di atas',

    // Comparison table
    efficiency: 'EFISIENSI ALTERNATIF',
    yourChoice: 'PILIHAN ANDA',
    bestMode: 'PILIHAN TERBAIK 🌿',
    routeUnavailable: 'Rute tidak tersedia',
    greenest: 'Paling Ramah',

    // KAI Warning
    kaiWarning: 'kemungkinan tidak dilayani KAI secara langsung. Estimasi emisi tetap dihitung sebagai referensi, namun pastikan ketersediaan jadwal di kai.id sebelum berangkat.',

    // Kereta hypothetical
    ifRouteExisted: 'Jalur kereta ini belum tersedia saat ini.',

    // Footer
    footerNote: 'Faktor emisi berdasarkan DEFRA Greenhouse Gas Reporting 2024. Jarak dihitung via OSRM routing engine. · Data tidak disimpan.',

    // Mobile collapsed bar
    changeRoute: 'Ubah Rute',

    // Status
    sessionStatus: 'STATUS SESI',

    // Save file
    saveTitle: 'TRIPTRACE - LAPORAN JEJAK KARBON',
    saveDate: 'Tanggal',
    saveRoute: 'Rute',
    saveDistance: 'Jarak',
    saveMode: 'Moda',
    saveEmission: 'Emisi',
    saveComparison: 'Perbandingan semua moda',
    saveAI: 'Saran AI',
    saveFooter: 'Data emisi berdasarkan DEFRA 2024.',

    // Edu page
    eduTitle: 'Tentang Karbon',
    eduHero: 'Kenapa jejak karbon perjalananmu penting?',
    eduSub: 'Sebelum kamu hitung emisimu, ada baiknya pahami dulu apa yang sebenarnya sedang kita ukur — dan kenapa ini penting buat bumi kita.',
  }
};

export default function App() {
  const [lang, setLang] = useState<'en' | 'id'>('en');
  const t = T[lang];
  const [showHomepage, setShowHomepage] = useState(true);
  const [showEduPage, setShowEduPage] = useState(false);
  const [insightMode, setInsightMode] = useState<'general' | 'transport' | 'fact'>('general');
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [transport, setTransport] = useState('pesawat');
  const [pax, setPax] = useState(1);
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [distance, setDistance] = useState<number | null>(null);
  const [emissions, setEmissions] = useState<number | null>(null);
  const [recommendation, setRecommendation] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [toast, setToast] = useState<string | null>(null);
  const [apiStatus, setApiStatus] = useState<'connected' | 'fact_mode' | 'unavailable'>('connected');
  const [isMobileFormCollapsed, setIsMobileFormCollapsed] = useState(false);
  const [tripLegs, setTripLegs] = useState<{ mode: string, desc: string, dist: number, emis: number, icon: React.ReactNode, isEstimated?: boolean }[]>([]);
  const [mapLegs, setMapLegs] = useState<MapLeg[]>([]);
  const [mapLoading, setMapLoading] = useState(false);
  const [loadingText, setLoadingText] = useState('Processing');
  const [comparisons, setComparisons] = useState<{id: string, val: number, isValid: boolean}[]>([]);
  
  // Validation states
  const [originError, setOriginError] = useState('');
  const [destError, setDestError] = useState('');
  const [kaiStatus, setKaiStatus] = useState<{ type: 'warning' | 'success', message: string } | null>(null);
  const [isKaiRouteValid, setIsKaiRouteValid] = useState(false);
  const [originDisplayName, setOriginDisplayName] = useState('');
  const [destDisplayName, setDestDisplayName] = useState('');
  
  // Autocomplete states
  const [originSuggestions, setOriginSuggestions] = useState<any[]>([]);
  const [destSuggestions, setDestSuggestions] = useState<any[]>([]);
  const [showOriginSuggestions, setShowOriginSuggestions] = useState(false);
  const [showDestSuggestions, setShowDestSuggestions] = useState(false);
  const [originIndex, setOriginIndex] = useState(-1);
  const [destIndex, setDestIndex] = useState(-1);
  const [searchTimer, setSearchTimer] = useState<NodeJS.Timeout | null>(null);

  const KAI_REGIONS = {
    "Jawa": ["DKI Jakarta", "Jawa Barat", "Jawa Tengah", "DI Yogyakarta", "Jawa Timur", "Banten"],
    "Sumatera": ["Sumatera Utara", "Sumatera Barat", "Sumatera Selatan", "Lampung"]
  };

  // Major Indonesian Cities (Ordered by importance/popularity)
  const CITY_PROVINCE: Record<string, string> = {
    'Jakarta': 'DKI JAKARTA',
    'Surabaya': 'JAWA TIMUR',
    'Bandung': 'JAWA BARAT',
    'Medan': 'SUMATERA UTARA',
    'Semarang': 'JAWA TENGAH',
    'Makassar': 'SULAWESI SELATAN',
    'Pekanbaru': 'RIAU',
    'Palembang': 'SUMATERA SELATAN',
    'Tangerang': 'BANTEN',
    'Depok': 'JAWA BARAT',
    'Bekasi': 'JAWA BARAT',
    'Bogor': 'JAWA BARAT',
    'Yogyakarta': 'DI YOGYAKARTA',
    'Solo': 'JAWA TENGAH',
    'Malang': 'JAWA TIMUR',
    'Denpasar': 'BALI',
    'Batam': 'KEPULAUAN RIAU',
    'Padang': 'SUMATERA BARAT',
    'Balikpapan': 'KALIMANTAN TIMUR',
    'Banjarmasin': 'KALIMANTAN SELATAN',
    'Pontianak': 'KALIMANTAN BARAT',
    'Samarinda': 'KALIMANTAN TIMUR',
    'Manado': 'SULAWESI UTARA',
    'Ambon': 'MALUKU',
    'Jayapura': 'PAPUA',
    'Kupang': 'NTT',
    'Mataram': 'NTB',
    'Banda Aceh': 'ACEH',
    'Jambi': 'JAMBI',
    'Bengkulu': 'BENGKULU',
    'Lampung': 'LAMPUNG',
    'Dumai': 'RIAU',
    'Bangkinang': 'RIAU',
    'Kandis': 'RIAU',
    'Bukittinggi': 'SUMATERA BARAT',
    'Blitar': 'JAWA TIMUR',
    'Kediri': 'JAWA TIMUR',
    'Tegal': 'JAWA TENGAH',
    'Purwokerto': 'JAWA TENGAH',
    'Cirebon': 'JAWA BARAT',
    'Tasikmalaya': 'JAWA BARAT',
    'Sukabumi': 'JAWA BARAT',
    'Jember': 'JAWA TIMUR',
    'Banyuwangi': 'JAWA TIMUR',
    'Madiun': 'JAWA TIMUR',
    'Probolinggo': 'JAWA TIMUR',
    'Pasuruan': 'JAWA TIMUR',
    'Mojokerto': 'JAWA TIMUR',
    'Sidoarjo': 'JAWA TIMUR',
    'Gresik': 'JAWA TIMUR',
    'Lamongan': 'JAWA TIMUR',
    'Tuban': 'JAWA TIMUR',
    'Bojonegoro': 'JAWA TIMUR',
    'Jombang': 'JAWA TIMUR',
    'Tulungagung': 'JAWA TIMUR',
    'Tarakan': 'KALIMANTAN UTARA',
    'Bontang': 'KALIMANTAN TIMUR',
    'Palu': 'SULAWESI TENGAH',
    'Kendari': 'SULAWESI TENGGARA',
    'Gorontalo': 'GORONTALO',
    'Ternate': 'MALUKU UTARA',
    'Sorong': 'PAPUA BARAT',
    'Merauke': 'PAPUA',
    'Lhokseumawe': 'ACEH',
    'Langsa': 'ACEH',
    'Binjai': 'SUMATERA UTARA',
    'Pematangsiantar': 'SUMATERA UTARA',
    'Padang Sidempuan': 'SUMATERA UTARA',
    'Lubuklinggau': 'SUMATERA SELATAN',
    'Prabumulih': 'SUMATERA SELATAN',
    'Metro': 'LAMPUNG',
    'Kotabumi': 'LAMPUNG',
    'Singkawang': 'KALIMANTAN BARAT',
    'Palangkaraya': 'KALIMANTAN TENGAH',
    'Labuan Bajo': 'NTT',
    'Bima': 'NTB',
    'Maumere': 'NTT',
    'Ende': 'NTT',
  };

  const MAJOR_CITIES = [
    { name: "Jakarta", state: "DKI Jakarta" },
    { name: "Surabaya", state: "Jawa Timur" },
    { name: "Bandung", state: "Jawa Barat" },
    { name: "Medan", state: "Sumatera Utara" },
    { name: "Semarang", state: "Jawa Tengah" },
    { name: "Makassar", state: "Sulawesi Selatan" },
    { name: "Palembang", state: "Sumatera Selatan" },
    { name: "Tangerang", state: "Banten" },
    { name: "Depok", state: "Jawa Barat" },
    { name: "Bekasi", state: "Jawa Barat" },
    { name: "Bogor", state: "Jawa Barat" },
    { name: "Pekanbaru", state: "Riau" },
    { name: "Batam", state: "Kepulauan Riau" },
    { name: "Padang", state: "Sumatera Barat" },
    { name: "Malang", state: "Jawa Timur" },
    { name: "Denpasar", state: "Bali" },
    { name: "Yogyakarta", state: "DI Yogyakarta" },
    { name: "Balikpapan", state: "Kalimantan Timur" },
    { name: "Banjarmasin", state: "Kalimantan Selatan" },
    { name: "Pontianak", state: "Kalimantan Barat" },
    { name: "Samarinda", state: "Kalimantan Timur" },
    { name: "Manado", state: "Sulawesi Utara" },
    { name: "Ambon", state: "Maluku" },
    { name: "Jayapura", state: "Papua" },
    { name: "Kupang", state: "Nusa Tenggara Timur" },
    { name: "Mataram", state: "Nusa Tenggara Barat" },
    { name: "Banda Aceh", state: "Aceh" },
    { name: "Bandar Lampung", state: "Lampung" },
    { name: "Solo", state: "Jawa Tengah" },
    { name: "Sidoarjo", state: "Jawa Timur" },
    { name: "Gresik", state: "Jawa Timur" },
    
    // Aceh & North Sumatra
    { name: "Banda Aceh", state: "Aceh" },
    { name: "Lhokseumawe", state: "Aceh" },
    { name: "Langsa", state: "Aceh" },
    { name: "Sabang", state: "Aceh" },
    { name: "Meulaboh", state: "Aceh" },
    { name: "Bireuen", state: "Aceh" },
    { name: "Takengon", state: "Aceh" },
    { name: "Subulussalam", state: "Aceh" },
    { name: "Medan", state: "Sumatera Utara" },
    { name: "Sibolga", state: "Sumatera Utara" },
    { name: "Padang Sidempuan", state: "Sumatera Utara" },
    { name: "Pematangsiantar", state: "Sumatera Utara" },
    { name: "Tanjungbalai", state: "Sumatera Utara" },
    { name: "Binjai", state: "Sumatera Utara" },
    { name: "Tebing Tinggi", state: "Sumatera Utara" },
    { name: "Gunungsitoli", state: "Sumatera Utara" },
    
    // South & Central Sumatra
    { name: "Palembang", state: "Sumatera Selatan" },
    { name: "Lubuklinggau", state: "Sumatera Selatan" },
    { name: "Prabumulih", state: "Sumatera Selatan" },
    { name: "Pagar Alam", state: "Sumatera Selatan" },
    { name: "Muara Enim", state: "Sumatera Selatan" },
    { name: "Jambi", state: "Jambi" },
    { name: "Bengkulu", state: "Bengkulu" },
    { name: "Bandar Lampung", state: "Lampung" },
    { name: "Metro", state: "Lampung" },
    { name: "Kotabumi", state: "Lampung" },
    { name: "Liwa", state: "Lampung" },
    { name: "Pringsewu", state: "Lampung" },
    { name: "Pangkal Pinang", state: "Bangka Belitung" },
    { name: "Tanjung Pinang", state: "Kepulauan Riau" },
    
    // Jawa Timur Expanded
    { name: "Surabaya", state: "Jawa Timur" },
    { name: "Malang", state: "Jawa Timur" },
    { name: "Jember", state: "Jawa Timur" },
    { name: "Banyuwangi", state: "Jawa Timur" },
    { name: "Probolinggo", state: "Jawa Timur" },
    { name: "Madiun", state: "Jawa Timur" },
    { name: "Kediri", state: "Jawa Timur" },
    { name: "Blitar", state: "Jawa Timur" },
    { name: "Pasuruan", state: "Jawa Timur" },
    { name: "Mojokerto", state: "Jawa Timur" },
    { name: "Batu", state: "Jawa Timur" },
    { name: "Jombang", state: "Jawa Timur" },
    { name: "Tulungagung", state: "Jawa Timur" },
    { name: "Lumajang", state: "Jawa Timur" },
    { name: "Situbondo", state: "Jawa Timur" },
    { name: "Bondowoso", state: "Jawa Timur" },
    { name: "Nganjuk", state: "Jawa Timur" },
    { name: "Ngawi", state: "Jawa Timur" },
    { name: "Bojonegoro", state: "Jawa Timur" },
    { name: "Tuban", state: "Jawa Timur" },
    { name: "Lamongan", state: "Jawa Timur" },
    { name: "Pamekasan", state: "Jawa Timur" },
    { name: "Sumenep", state: "Jawa Timur" },
    
    // Riau Expanded
    { name: "Pekanbaru", state: "Riau" },
    { name: "Dumai", state: "Riau" },
    { name: "Duri", state: "Riau" },
    { name: "Kandis", state: "Riau" },
    { name: "Bengkalis", state: "Riau" },
    { name: "Tembilahan", state: "Riau" },
    { name: "Rengat", state: "Riau" },
    { name: "Pangkalan Kerinci", state: "Riau" },
    { name: "Siak", state: "Riau" },
    { name: "Selat Panjang", state: "Riau" },
    { name: "Bagan Siapi-api", state: "Riau" },
    
    // Sumatera Barat Expanded
    { name: "Padang", state: "Sumatera Barat" },
    { name: "Bukittinggi", state: "Sumatera Barat" },
    { name: "Payakumbuh", state: "Sumatera Barat" },
    { name: "Solok", state: "Sumatera Barat" },
    { name: "Sawahlunto", state: "Sumatera Barat" },
    { name: "Padang Panjang", state: "Sumatera Barat" },
    { name: "Pariaman", state: "Sumatera Barat" },
    
    // West & Central Java
    { name: "Jakarta", state: "DKI Jakarta" },
    { name: "Bandung", state: "Jawa Barat" },
    { name: "Depok", state: "Jawa Barat" },
    { name: "Bekasi", state: "Jawa Barat" },
    { name: "Bogor", state: "Jawa Barat" },
    { name: "Tangerang", state: "Banten" },
    { name: "Semarang", state: "Jawa Tengah" },
    { name: "Yogyakarta", state: "DI Yogyakarta" },
    { name: "Solo", state: "Jawa Tengah" },
    { name: "Tasikmalaya", state: "Jawa Barat" },
    { name: "Serang", state: "Banten" },
    { name: "Cirebon", state: "Jawa Barat" },
    { name: "Cilegon", state: "Banten" },
    { name: "Sukabumi", state: "Jawa Barat" },
    { name: "Salatiga", state: "Jawa Tengah" },
    { name: "Cimahi", state: "Jawa Barat" },
    
    // Kalimantan Expanded
    { name: "Pontianak", state: "Kalimantan Barat" },
    { name: "Singkawang", state: "Kalimantan Barat" },
    { name: "Sambas", state: "Kalimantan Barat" },
    { name: "Ketapang", state: "Kalimantan Barat" },
    { name: "Sintang", state: "Kalimantan Barat" },
    { name: "Putussibau", state: "Kalimantan Barat" },
    { name: "Banjarmasin", state: "Kalimantan Selatan" },
    { name: "Banjarbaru", state: "Kalimantan Selatan" },
    { name: "Tanjung", state: "Kalimantan Selatan" },
    { name: "Balikpapan", state: "Kalimantan Timur" },
    { name: "Samarinda", state: "Kalimantan Timur" },
    { name: "Bontang", state: "Kalimantan Timur" },
    { name: "Sangatta", state: "Kalimantan Timur" },
    { name: "Tarakan", state: "Kalimantan Utara" },
    { name: "Nunukan", state: "Kalimantan Utara" },
    { name: "Tanjung Selor", state: "Kalimantan Utara" },
    { name: "Palangkaraya", state: "Kalimantan Tengah" },
    
    // Sulawesi Expanded
    { name: "Makassar", state: "Sulawesi Selatan" },
    { name: "Parepare", state: "Sulawesi Selatan" },
    { name: "Palopo", state: "Sulawesi Selatan" },
    { name: "Manado", state: "Sulawesi Utara" },
    { name: "Bitung", state: "Sulawesi Utara" },
    { name: "Tomohon", state: "Sulawesi Utara" },
    { name: "Kotamobagu", state: "Sulawesi Utara" },
    { name: "Palu", state: "Sulawesi Tengah" },
    { name: "Kendari", state: "Sulawesi Tenggara" },
    { name: "Bau-Bau", state: "Sulawesi Tenggara" },
    { name: "Gorontalo", state: "Gorontalo" },
    { name: "Mamuju", state: "Sulawesi Barat" },
    { name: "Majene", state: "Sulawesi Barat" },
    { name: "Polewali", state: "Sulawesi Barat" },
    { name: "Mamasa", state: "Sulawesi Barat" },
    { name: "Masamba", state: "Sulawesi Selatan" },
    { name: "Wonomulyo", state: "Sulawesi Barat" },
    
    // Maluku & Papua Expanded
    { name: "Ambon", state: "Maluku" },
    { name: "Ternate", state: "Maluku Utara" },
    { name: "Tobelo", state: "Maluku Utara" },
    { name: "Tidore", state: "Maluku Utara" },
    { name: "Morotai", state: "Maluku Utara" },
    { name: "Jayapura", state: "Papua" },
    { name: "Sorong", state: "Papua Barat" },
    { name: "Manokwari", state: "Papua Barat" },
    { name: "Wamena", state: "Papua Pegunungan" },
    { name: "Merauke", state: "Papua Selatan" },
    { name: "Timika", state: "Papua Tengah" },
    { name: "Biak", state: "Papua" },
    { name: "Serui", state: "Papua" },
    { name: "Nabire", state: "Papua Tengah" },
    
    // Bali & Nusa Tenggara Expanded
    { name: "Denpasar", state: "Bali" },
    { name: "Mataram", state: "Nusa Tenggara Barat" },
    { name: "Bima", state: "Nusa Tenggara Barat" },
    { name: "Dompu", state: "Nusa Tenggara Barat" },
    { name: "Sumbawa Besar", state: "Nusa Tenggara Barat" },
    { name: "Praya", state: "Nusa Tenggara Barat" },
    { name: "Kupang", state: "Nusa Tenggara Timur" },
    { name: "Maumere", state: "Nusa Tenggara Timur" },
    { name: "Ende", state: "Nusa Tenggara Timur" },
    { name: "Ruteng", state: "Nusa Tenggara Timur" },
    { name: "Bajawa", state: "Nusa Tenggara Timur" },
    { name: "Labuan Bajo", state: "Nusa Tenggara Timur" },
    { name: "Atambua", state: "Nusa Tenggara Timur" },
    { name: "Kefamenanu", state: "Nusa Tenggara Timur" },
    { name: "Soe", state: "Nusa Tenggara Timur" }
  ];

  function getSimilarity(s1: string, s2: string): number {
    let longer = s1.toLowerCase().trim();
    let shorter = s2.toLowerCase().trim();
    if (longer.length < shorter.length) {
      let temp = longer;
      longer = shorter;
      shorter = temp;
    }
    const longerLength = longer.length;
    if (longerLength === 0) return 1.0;
    
    const editDistance = (a: string, b: string) => {
      const costs = new Array();
      for (let i = 0; i <= a.length; i++) {
        let lastValue = i;
        for (let j = 0; j <= b.length; j++) {
          if (i == 0) costs[j] = j;
          else {
            if (j > 0) {
              let newValue = costs[j - 1];
              if (a.charAt(i - 1) != b.charAt(j - 1))
                newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
              costs[j - 1] = lastValue;
              lastValue = newValue;
            }
          }
        }
        if (i > 0) costs[b.length] = lastValue;
      }
      return costs[b.length];
    };

    return (longerLength - editDistance(longer, shorter)) / longerLength;
  }

  function toTitleCase(str: string): string {
    return str
      .toLowerCase()
      .trim()
      .split(/\s+/)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }

  function getHaversineDistance(c1: Coordinates, c2: Coordinates): number {
    const R = 6371;
    const dLat = (parseFloat(c2.lat) - parseFloat(c1.lat)) * Math.PI / 180;
    const dLon = (parseFloat(c2.lon) - parseFloat(c1.lon)) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(parseFloat(c1.lat) * Math.PI / 180) * Math.cos(parseFloat(c2.lat) * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  async function getCoordinates(input: string): Promise<Coordinates | null> {
    const q = input.toLowerCase().trim();
    if (!q) return null;

    // 1. Fuzzy match against local MAJOR_CITIES
    let bestMatch = null;
    let maxSimilarity = 0;

    for (const city of MAJOR_CITIES) {
      const cityName = city.name.toLowerCase();
      const fullName = `${city.name}, ${city.state}`.toLowerCase();
      
      const s1 = getSimilarity(q, cityName);
      const s2 = getSimilarity(q, fullName);
      const currentMax = Math.max(s1, s2);

      if (currentMax > maxSimilarity) {
        maxSimilarity = currentMax;
        bestMatch = `${city.name}, ${city.state}`;
      }
    }

    // Similarity threshold > 80% as requested
    const queryName = maxSimilarity > 0.8 ? bestMatch! : input;

    // 2. Geocode via Nominatim (either the fuzzy match or original input)
    try {
      const geoParams = `&featuretype=settlement&bounded=1&viewbox=95.0,5.5,141.0,-11.0&limit=5`;
      const response = await fetch(`/api/search?q=${encodeURIComponent(queryName + ", Indonesia")}${geoParams}`);
      const data = await response.json();
      
      if (data && data.length > 0) {
        // Loop through results to find valid type
        for (const res of data) {
          const type = res.addresstype || res.type;
          if (['city', 'town', 'village', 'administrative'].includes(type)) {
            return {
              lat: res.lat,
              lon: res.lon,
              name: res.display_name
            };
          }
        }
      }
      
      // 3. Last fallback
      if (maxSimilarity > 0.8 && queryName !== input) {
        const fallbackRes = await fetch(`/api/search?q=${encodeURIComponent(input + ", Indonesia")}${geoParams}`);
        const fallbackData = await fallbackRes.json();
        if (fallbackData && fallbackData.length > 0) {
          for (const res of fallbackData) {
            const type = res.addresstype || res.type;
            if (['city', 'town', 'village', 'administrative'].includes(type)) {
              return { lat: res.lat, lon: res.lon, name: res.display_name };
            }
          }
        }
      }
    } catch (e) {
      console.error("Resolve error:", e);
    }

    return null;
  }

  function normalizeNominatimResult(result: any): { city: string, province: string } | null {
    const addr = result.address || {};
    
    // Ambil nama kota — prioritas: city > town > village > county
    const city = addr.city || addr.town || addr.village || addr.county || '';
    
    // Ambil provinsi
    const province = addr.state || addr.province || '';
    
    // Blacklist nama yang terlalu panjang atau mengandung kata administratif formal
    const blacklist = [
      'daerah khusus', 'daerah istimewa', 
      'kabupaten', 'kecamatan', 'kelurahan',
      'kotamadya', 'propinsi', 'provinsi'
    ];
    
    const cityLower = city.toLowerCase();
    const isBlacklisted = blacklist.some(b => 
      cityLower.includes(b)
    );
    
    if (!city || isBlacklisted) return null;
    
    return { city, province: province.toUpperCase() };
  }

  async function fetchSuggestions(query: string, type: 'origin' | 'dest') {
    if (query.length < 2) {
      if (type === 'origin') setOriginSuggestions([]);
      else setDestSuggestions([]);
      return;
    }

    if (searchTimer) clearTimeout(searchTimer);

    const timeout = setTimeout(async () => {
      const q = query.toLowerCase();
      
      // 1. Filter local MAJOR_CITIES and map to consistent structure
      const localMatches = MAJOR_CITIES.filter(city => 
        city.name.toLowerCase().includes(q)
      ).sort((a, b) => {
        const aName = a.name.toLowerCase();
        const bName = b.name.toLowerCase();
        const aStarts = aName.startsWith(q);
        const bStarts = bName.startsWith(q);
        if (aStarts && !bStarts) return -1;
        if (!aStarts && bStarts) return 1;
        return MAJOR_CITIES.indexOf(a) - MAJOR_CITIES.indexOf(b);
      });

      const localSuggestions = localMatches.map(city => {
        const province = CITY_PROVINCE[city.name] || city.state.toUpperCase();
        return {
          city: city.name,
          province,
          display_name: `${city.name}, ${province}`,
          isLocal: true
        };
      });

      // 2. Fetch from Nominatim API as fallback
      let nominatimResults: any[] = [];
      try {
        const geoParams = `&featuretype=settlement&bounded=1&viewbox=95.0,5.5,141.0,-11.0&limit=10`;
        const response = await fetch(`/api/search?q=${encodeURIComponent(query + ", Indonesia")}${geoParams}`);
        const rawResults = await response.json();
        
        if (Array.isArray(rawResults)) {
          nominatimResults = rawResults
            .map(res => normalizeNominatimResult(res))
            .filter(res => res !== null);
        }
      } catch (e) {
        console.error("Nominatim fetch error:", e);
      }

      // 3. Combined & Deduplicate strictly
      const seen = new Set<string>();
      const finalLocal: any[] = [];
      const finalNominatim: any[] = [];

      // Process local first
      localSuggestions.forEach(item => {
        const key = item.city.toLowerCase().replace(/\s+/g, '');
        if (!seen.has(key)) {
          seen.add(key);
          finalLocal.push(item);
        }
      });

      // Process Nominatim (after local to preserve priority)
      nominatimResults.forEach(item => {
        const key = item.city.toLowerCase().replace(/\s+/g, '');
        if (!seen.has(key)) {
          seen.add(key);
          finalNominatim.push({
            city: item.city,
            province: item.province,
            display_name: `${item.city}, ${item.province}`,
            isLocal: false
          });
        }
      });

      // 4. Priority Tampilan
      // - Hasil lokal yang match dulu
      // - Nominatim maksimal 2 hasil tambahan
      // - Total maksimal 7 item
      const combined = [
        ...finalLocal,
        ...finalNominatim.slice(0, 2)
      ].slice(0, 7);

      if (type === 'origin') {
        setOriginSuggestions(combined);
        setOriginIndex(-1);
      } else {
        setDestSuggestions(combined);
        setDestIndex(-1);
      }
    }, 300);

    setSearchTimer(timeout);
  }

  const handleKeyDown = (e: React.KeyboardEvent, type: 'origin' | 'dest') => {
    const suggestions = type === 'origin' ? originSuggestions : destSuggestions;
    const index = type === 'origin' ? originIndex : destIndex;
    const setIndex = type === 'origin' ? setOriginIndex : setDestIndex;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setIndex(prev => (prev < suggestions.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setIndex(prev => (prev > 0 ? prev - 1 : 0));
    } else if (e.key === 'Enter' && index >= 0) {
      e.preventDefault();
      const selected = suggestions[index];
      if (type === 'origin') {
        setOrigin(formatDisplayName(selected));
        setShowOriginSuggestions(false);
      } else {
        setDestination(formatDisplayName(selected));
        setShowDestSuggestions(false);
      }
    } else if (e.key === 'Escape') {
      setShowOriginSuggestions(false);
      setShowDestSuggestions(false);
    }
  };

  async function getRoadDistance(coord1: {lat: string, lon: string}, coord2: {lat: string, lon: string}): Promise<{ dist: number, isEstimated: boolean }> {
    try {
      const response = await fetch(`/api/route?coords=${coord1.lon},${coord1.lat};${coord2.lon},${coord2.lat}`);
      const data = await response.json();
      if (data.code !== 'Ok') throw new Error("Rute tidak ditemukan");
      return { dist: data.routes[0].distance / 1000, isEstimated: false };
    } catch (e) {
      // Fallback to Haversine if OSRM fails
      return { dist: getHaversineDistance(coord1 as Coordinates, coord2 as Coordinates) * 1.3, isEstimated: true };
    }
  }

  async function calculateTrip(currentMode: string, baseDist: number, originName: string, destName: string, currentPax: number, originCoord?: {lat: string, lon: string}, destCoord?: {lat: string, lon: string}) {
    const legs: { 
      mode: string, 
      desc: string, 
      dist: number, 
      emis: number, 
      icon: React.ReactNode, 
      isEstimated?: boolean,
      fromCoord: {lat: number, lon: number},
      toCoord: {lat: number, lon: number},
      fromName: string,
      toName: string,
      isFerry?: boolean,
      isPlane?: boolean
    }[] = [];
    
    const getIsland = (name: string) => {
      const normalizedQuery = name.split(',')[0].trim();
      const cityKey = Object.keys(ISLAND_MAP).find(c => 
        normalizedQuery.toLowerCase().includes(c.toLowerCase()) || 
        c.toLowerCase().includes(normalizedQuery.toLowerCase())
      );
      return cityKey ? ISLAND_MAP[cityKey] : null;
    };

    const originIsland = getIsland(originName);
    const destIsland = getIsland(destName);

    const resolveAirport = (cityName: string): {
      airport_name: string,
      airport_city: string,
      coord: { lat: number, lon: number }
    } | null => {
      // Cek apakah kota punya bandara sendiri
      const normalized = toTitleCase(cityName.trim());
      if (AIRPORT_COORDS[normalized]) {
        return {
          airport_name: AIRPORT_COORDS[normalized].airport_name,
          airport_city: normalized,
          coord: AIRPORT_COORDS[normalized].coord
        };
      }
      // Cek nearest airport
      if (NEAREST_AIRPORT[normalized]) {
        const na = NEAREST_AIRPORT[normalized];
        return {
          airport_name: na.airport_name,
          airport_city: na.airport_city,
          coord: na.airport_coord
        };
      }
      return null;
    };

    if (currentMode === 'pesawat') {
      const originAirport = resolveAirport(originName);
      const destAirport = resolveAirport(destName);

      if (!originAirport || !destAirport) {
        legs.push({
          mode: 'pesawat',
          desc: `${originName.split(',')[0]} → ${destName.split(',')[0]}`,
          dist: baseDist,
          emis: baseDist * FACTORS.pesawat,
          icon: <Plane className="w-4 h-4" />,
          fromCoord: { lat: parseFloat(originCoord!.lat), lon: parseFloat(originCoord!.lon) },
          toCoord: { lat: parseFloat(destCoord!.lat), lon: parseFloat(destCoord!.lon) },
          fromName: originName.split(',')[0],
          toName: destName.split(',')[0],
          isPlane: true
        });
      } else {
        if (currentMode === transport) setLoadingText(lang === 'en' ? "Finding Nearest Airports..." : "Mencari Bandara Terdekat...");

        // LEG 1: Kota asal → Bandara asal (darat)
        if (originAirport.airport_city !== toTitleCase(originName.split(',')[0])) {
          const d1 = await getRoadDistance(originCoord!, {
            lat: String(originAirport.coord.lat),
            lon: String(originAirport.coord.lon)
          });
          legs.push({
            mode: 'motor',
            desc: `${originName.split(',')[0]} → ${originAirport.airport_name} (Darat)`,
            dist: d1.dist,
            emis: d1.dist * FACTORS.motor,
            icon: <Car className="w-4 h-4" />,
            isEstimated: d1.isEstimated,
            fromCoord: { lat: parseFloat(originCoord!.lat), lon: parseFloat(originCoord!.lon) },
            toCoord: { lat: originAirport.coord.lat, lon: originAirport.coord.lon },
            fromName: originName.split(',')[0],
            toName: originAirport.airport_name
          });
        }

        if (currentMode === transport) setLoadingText(lang === 'en' ? "Calculating Flight Route..." : "Menghitung Rute Penerbangan...");

        // LEG 2: Bandara asal → Bandara tujuan
        const flightDist = getHaversineDistance(
          { lat: String(originAirport.coord.lat), lon: String(originAirport.coord.lon), name: 'Origin Airport' },
          { lat: String(destAirport.coord.lat), lon: String(destAirport.coord.lon), name: 'Dest Airport' }
        ) * 1.1;
        legs.push({
          mode: 'pesawat',
          desc: `${originAirport.airport_name} → ${destAirport.airport_name} (Pesawat)`,
          dist: flightDist,
          emis: flightDist * FACTORS.pesawat,
          icon: <Plane className="w-4 h-4" />,
          fromCoord: { lat: originAirport.coord.lat, lon: originAirport.coord.lon },
          toCoord: { lat: destAirport.coord.lat, lon: destAirport.coord.lon },
          fromName: originAirport.airport_name,
          toName: destAirport.airport_name,
          isPlane: true
        });

        if (currentMode === transport) setLoadingText(lang === 'en' ? "Finalizing Calculation..." : "Menyelesaikan Kalkulasi...");

        // LEG 3: Bandara tujuan → Kota tujuan (darat)
        if (destAirport.airport_city !== toTitleCase(destName.split(',')[0])) {
          const d2 = await getRoadDistance({
            lat: String(destAirport.coord.lat),
            lon: String(destAirport.coord.lon)
          }, destCoord!);
          legs.push({
            mode: 'motor',
            desc: `${destAirport.airport_name} → ${destName.split(',')[0]} (Darat)`,
            dist: d2.dist,
            emis: d2.dist * FACTORS.motor,
            icon: <Car className="w-4 h-4" />,
            isEstimated: d2.isEstimated,
            fromCoord: { lat: destAirport.coord.lat, lon: destAirport.coord.lon },
            toCoord: { lat: parseFloat(destCoord!.lat), lon: parseFloat(destCoord!.lon) },
            fromName: destAirport.airport_name,
            toName: destName.split(',')[0]
          });
        }
      }
    } else if (['mobil', 'motor', 'bus'].includes(currentMode) && originIsland && destIsland && originIsland !== destIsland && originCoord && destCoord) {
      let ferryKey = `${originIsland}-${destIsland}`;
      
      // Sumatera ↔ Batam
      if ((originIsland === 'sumatera' && destIsland === 'batam') ||
          (originIsland === 'sumatera' && destIsland === 'bintan'))
        ferryKey = 'sumatera-batam';

      if ((originIsland === 'batam' && destIsland === 'sumatera') ||
          (originIsland === 'bintan' && destIsland === 'sumatera'))
        ferryKey = 'batam-sumatera';

      // Sumatera ↔ Bangka
      if (originIsland === 'sumatera' && destIsland === 'bangka')
        ferryKey = 'sumatera-bangka';
      if (originIsland === 'bangka' && destIsland === 'sumatera')
        ferryKey = 'bangka-sumatera';

      // Lombok ↔ Sumbawa
      if (originIsland === 'lombok' && destIsland === 'sumbawa')
        ferryKey = 'lombok-sumbawa';
      if (originIsland === 'sumbawa' && destIsland === 'lombok')
        ferryKey = 'sumbawa-lombok';

      // Kalimantan ↔ Sulawesi
      if (originIsland === 'kalimantan' && destIsland === 'sulawesi')
        ferryKey = 'kalimantan-sulawesi';
      if (originIsland === 'sulawesi' && destIsland === 'kalimantan')
        ferryKey = 'sulawesi-kalimantan';

      const ferryRoute = FERRY_ROUTES[ferryKey];

      if (ferryRoute) {
        if (currentMode === transport) setLoadingText(lang === 'en' ? "Calculating Ferry Route..." : "Menghitung Rute Feri...");
        // Darat 1
        const d1 = await getRoadDistance(originCoord, {
          lat: String(ferryRoute.port_origin_coord.lat),
          lon: String(ferryRoute.port_origin_coord.lon)
        });
        const d1Emis = (d1.dist * FACTORS[currentMode as keyof typeof FACTORS]) / (currentMode === 'mobil' ? currentPax : 1);
        legs.push({
          mode: currentMode,
          desc: `${originName.split(',')[0]} → ${ferryRoute.port_origin}`,
          dist: d1.dist,
          emis: d1Emis,
          icon: currentMode === 'mobil' ? <Car className="w-4 h-4" /> : currentMode === 'motor' ? <Bike className="w-4 h-4" /> : <Bus className="w-4 h-4" />,
          isEstimated: d1.isEstimated,
          fromCoord: { lat: parseFloat(originCoord.lat), lon: parseFloat(originCoord.lon) },
          toCoord: { lat: ferryRoute.port_origin_coord.lat, lon: ferryRoute.port_origin_coord.lon },
          fromName: originName.split(',')[0],
          toName: ferryRoute.port_origin
        });
        // Feri
        legs.push({
          mode: 'ferry',
          desc: `${ferryRoute.port_origin} → ${ferryRoute.port_dest} (Feri)`,
          dist: ferryRoute.distance_km,
          emis: ferryRoute.distance_km * FACTORS.ferry,
          icon: <Ship className="w-4 h-4" />,
          fromCoord: { lat: ferryRoute.port_origin_coord.lat, lon: ferryRoute.port_origin_coord.lon },
          toCoord: { lat: ferryRoute.port_dest_coord.lat, lon: ferryRoute.port_dest_coord.lon },
          fromName: ferryRoute.port_origin,
          toName: ferryRoute.port_dest,
          isFerry: true
        });
        // Darat 2
        const d2 = await getRoadDistance({
          lat: String(ferryRoute.port_dest_coord.lat),
          lon: String(ferryRoute.port_dest_coord.lon)
        }, destCoord);
        const d2Emis = (d2.dist * FACTORS[currentMode as keyof typeof FACTORS]) / (currentMode === 'mobil' ? currentPax : 1);
        legs.push({
          mode: currentMode,
          desc: `${ferryRoute.port_dest} → ${destName.split(',')[0]}`,
          dist: d2.dist,
          emis: d2Emis,
          icon: currentMode === 'mobil' ? <Car className="w-4 h-4" /> : currentMode === 'motor' ? <Bike className="w-4 h-4" /> : <Bus className="w-4 h-4" />,
          isEstimated: d2.isEstimated,
          fromCoord: { lat: ferryRoute.port_dest_coord.lat, lon: ferryRoute.port_dest_coord.lon },
          toCoord: { lat: parseFloat(destCoord.lat), lon: parseFloat(destCoord.lon) },
          fromName: ferryRoute.port_dest,
          toName: destName.split(',')[0]
        });
      } else {
        const emis = (baseDist * FACTORS[currentMode as keyof typeof FACTORS]) / (currentMode === 'mobil' ? currentPax : 1);
        legs.push({
          mode: currentMode,
          desc: `${originName.split(',')[0]} → ${destName.split(',')[0]}`,
          dist: baseDist,
          emis,
          icon: currentMode === 'mobil' ? <Car className="w-4 h-4" /> : currentMode === 'motor' ? <Bike className="w-4 h-4" /> : <Bus className="w-4 h-4" />,
          fromCoord: { lat: parseFloat(originCoord!.lat), lon: parseFloat(originCoord!.lon) },
          toCoord: { lat: parseFloat(destCoord!.lat), lon: parseFloat(destCoord!.lon) },
          fromName: originName.split(',')[0],
          toName: destName.split(',')[0]
        });
      }
    } else {
      const baseEmis = currentMode === 'mobil' 
        ? (FACTORS.mobil * baseDist) / currentPax 
        : (FACTORS[currentMode as keyof typeof FACTORS] || 0) * baseDist;
      
      let icon = <Car className="w-4 h-4" />;
      if (currentMode === 'pesawat') icon = <Plane className="w-4 h-4" />;
      if (currentMode === 'kereta') icon = <Train className="w-4 h-4" />;
      if (currentMode === 'motor') icon = <Bike className="w-4 h-4" />;
      if (currentMode === 'bus') icon = <Bus className="w-4 h-4" />;

      legs.push({
        mode: currentMode,
        desc: `${originName.split(',')[0]} → ${destName.split(',')[0]}`,
        dist: baseDist,
        emis: baseEmis,
        icon: icon,
        fromCoord: { lat: parseFloat(originCoord!.lat), lon: parseFloat(originCoord!.lon) },
        toCoord: { lat: parseFloat(destCoord!.lat), lon: parseFloat(destCoord!.lon) },
        fromName: originName.split(',')[0],
        toName: destName.split(',')[0]
      });
    }

    const totalEmis = legs.reduce((sum, l) => sum + l.emis, 0);
    const totalDist = legs.reduce((sum, l) => sum + l.dist, 0);
    return { totalEmis, totalDist, legs };
  }

  const formatDisplayName = (s: any) => {
    if (s.city && s.province) return `${s.city}, ${s.province}`;
    const addr = s.address || {};
    const city = addr.city || addr.town || addr.village || addr.county || (s.display_name ? s.display_name.split(',')[0] : "");
    const state = addr.state || addr.province || addr.region || "";
    if (city && state) return `${city}, ${state.toUpperCase()}`;
    return s.display_name || "";
  };

  function checkFeasibility(originData: any, destData: any, dist: number, originName: string, destName: string) {
    const newWarnings: string[] = [];
    
    const getProvince = (addr: any) => addr.state || addr.city_district || addr.region || "";
    const originProv = getProvince(originData.address);
    const destProv = getProvince(destData.address);

    const isProvinceServed = (prov: string) => {
      const allServed = [...KAI_REGIONS.Jawa, ...KAI_REGIONS.Sumatera];
      return allServed.some(served => prov.includes(served));
    };

    const isSameIsland = (p1: string, p2: string) => {
      const inJava = (p: string) => KAI_REGIONS.Jawa.some(sj => p.includes(sj));
      const inSumatra = (p: string) => KAI_REGIONS.Sumatera.some(ss => p.includes(ss));
      return (inJava(p1) && inJava(p2)) || (inSumatra(p1) && inSumatra(p2));
    };

    if (transport === 'kereta') {
      const isKAI = (name: string) => KAI_NETWORK_CITIES.some(city => 
        name.toLowerCase().includes(city.toLowerCase())
      );

      const isValid = isKAI(originName) && isKAI(destName);
      setIsKaiRouteValid(isValid);

      const originProvServed = isProvinceServed(originProv);
      const destProvServed = isProvinceServed(destProv);

      if (isValid) {
        setKaiStatus({ type: 'success', message: lang === 'en' ? 'KAI Route Available' : 'Rute KAI Tersedia' });
      } else {
        if (!originProvServed || !destProvServed) {
          if (!originProvServed && !destProvServed) {
            newWarnings.push(lang === 'en' ? `Both ${originName} and ${destName} are outside KAI's main operational areas (Java & Sumatra).` : `Kota ${originName} dan ${destName} berada di luar jangkauan operasional utama KAI (Jawa & Sumatera).`);
          } else if (!originProvServed) {
            newWarnings.push(lang === 'en' ? `${originName} is outside KAI's operational range. Trains might not be available at this location.` : `Kota ${originName} berada di luar jangkauan operasional KAI. Kereta api mungkin tidak tersedia di lokasi ini.`);
          } else {
            newWarnings.push(lang === 'en' ? `${destName} is outside KAI's operational range. Trains might not be available at this location.` : `Kota ${destName} berada di luar jangkauan operasional KAI. Kereta api mungkin tidak tersedia di lokasi ini.`);
          }
        } else {
          newWarnings.push(lang === 'en' ? `Route ${originName} → ${destName} might not be directly served by KAI. Please check schedules at kai.id.` : `Rute ${originName} → ${destName} kemungkinan tidak dilayani KAI secara langsung. Pastikan ketersediaan jadwal di kai.id sebelum berangkat.`);
        }
      }

      if (originProvServed && destProvServed && !isSameIsland(originProv, destProv)) {
        newWarnings.push(lang === 'en' ? "Railway systems in Java and Sumatra are currently not connected. You need air or sea transport to cross islands." : "Sistem kereta api di Jawa dan Sumatera saat ini belum terhubung. Anda memerlukan transportasi udara atau laut untuk menyeberang pulau.");
      }
    }

    if (transport === 'pesawat' && dist < 150) {
      newWarnings.push(lang === 'en' ? "This route's distance is too short for commercial flights. Land transport is much more efficient." : "Jarak tempuh rute ini terlalu pendek untuk penerbangan komersial. Jalur darat jauh lebih efisien.");
    }

    setWarnings(newWarnings);
  }

  async function handleCalculate() {
    setApiStatus('connected'); // reset ke default
    let hasError = false;
    
    // Reset errors first
    setOriginError('');
    setDestError('');

    if (!origin) {
      setOriginError(lang === 'en' ? 'Origin city is required.' : 'Kota asal wajib diisi.');
      hasError = true;
    }

    if (!destination) {
      setDestError(lang === 'en' ? 'Destination city is required.' : 'Kota tujuan wajib diisi.');
      hasError = true;
    }

    if (hasError) return;

    setLoading(true);
    setWarnings([]);
    setKaiStatus(null);
    setIsKaiRouteValid(false);

    const normOrigin = toTitleCase(origin);
    const normDest = toTitleCase(destination);
    setOriginDisplayName(normOrigin);
    setDestDisplayName(normDest);

    try {
      // Fuzzy Resolve locations
      const [originCoord, destCoord] = await Promise.all([
        getCoordinates(origin),
        getCoordinates(destination)
      ]);

      if (!originCoord) {
        setOriginError(lang === 'en' ? 'City not found. Try checking the spelling or use a more complete city name.' : 'Kota tidak ditemukan. Coba periksa ejaan atau gunakan nama kota yang lebih lengkap.');
        setLoading(false);
        return;
      }
      if (!destCoord) {
        setDestError(lang === 'en' ? 'City not found. Try checking the spelling or use a more complete city name.' : 'Kota tidak ditemukan. Coba periksa ejaan atau gunakan nama kota yang lebih lengkap.');
        setLoading(false);
        return;
      }

      setLoadingText(lang === 'en' ? "Calculating Route..." : "Menghitung Rute...");

      let baseDist = 0;
      if (transport === 'pesawat') {
        const haversine = getHaversineDistance(originCoord, destCoord);
        baseDist = haversine * 1.1;
      } else {
        const res = await getRoadDistance(originCoord, destCoord);
        baseDist = res.dist;
      }

      const trip = await calculateTrip(transport, baseDist, normOrigin, normDest, pax, originCoord, destCoord);
      setDistance(trip.totalDist);
      setEmissions(trip.totalEmis);
      setTripLegs(trip.legs);

      // Populate mapLegs
      const mapLegsData: MapLeg[] = trip.legs.map(leg => ({
        from: {
          lat: leg.fromCoord.lat,
          lon: leg.fromCoord.lon,
          name: leg.fromName
        },
        to: {
          lat: leg.toCoord.lat,
          lon: leg.toCoord.lon,
          name: leg.toName
        },
        mode: leg.isFerry ? 'feri' : leg.isPlane ? 'pesawat' : 'darat',
        emission: leg.emis
      }));

      // Fetch all geometries simultaneously
      setMapLoading(true);
      try {
        const legsWithGeometry = await Promise.all(
          mapLegsData.map(async (leg) => {
            if (leg.mode === 'darat') {
              const geometry = await getRouteGeometry(leg.from, leg.to);
              return { ...leg, geometry };
            }
            return leg;
          })
        );
        setMapLegs(legsWithGeometry);
      } finally {
        setMapLoading(false);
      }

      const selectedEmissions = trip.totalEmis;
      const dist = trip.totalDist;

      // Pre-calculate all comparisons
      const modes = ['pesawat', 'kereta', 'mobil', 'motor', 'bus'];
      const compResults = await Promise.all(modes.map(async (m) => {
        let isValid = true;
        if (m === 'kereta') {
          const isKAI = (name: string) => KAI_NETWORK_CITIES.some(city => 
            name.toLowerCase().includes(city.toLowerCase())
          );
          isValid = isKAI(normOrigin) && isKAI(normDest);
        }
        
        let mDist = baseDist;
        if (m === 'pesawat' && transport !== 'pesawat') {
          mDist = getHaversineDistance(originCoord, destCoord) * 1.1;
        } else if (m !== 'pesawat' && transport === 'pesawat') {
          const res = await getRoadDistance(originCoord, destCoord);
          mDist = res.dist;
        }

        const t = await calculateTrip(m, mDist, normOrigin, normDest, pax, originCoord, destCoord);
        return { id: m, val: t.totalEmis, isValid };
      }));
      setComparisons(compResults);

      // Get detailed data for feasibility check
      const commonParams = `&featuretype=settlement&bounded=1&viewbox=95.0,5.5,141.0,-11.0&limit=1`;
      const [originRes, destRes] = await Promise.all([
        fetch(`/api/search?q=${encodeURIComponent(originCoord.name)}${commonParams}`),
        fetch(`/api/search?q=${encodeURIComponent(destCoord.name)}${commonParams}`)
      ]);
      const [originData, destData] = await Promise.all([originRes.json(), destRes.json()]);

      if (originData.length > 0 && destData.length > 0) {
        checkFeasibility(originData[0], destData[0], dist, normOrigin, normDest);
      }
      
      const isKAI = (name: string) => KAI_NETWORK_CITIES.some(city => 
        name.toLowerCase().includes(city.toLowerCase())
      );
      const currentlyValidKai = isKAI(normOrigin) && isKAI(normDest);
      setIsKaiRouteValid(currentlyValidKai);

      setShowResults(true);

      const bestNonSelected = compResults
        .filter(m => m.id !== transport && m.isValid)
        .sort((a, b) => a.val - b.val)[0];

      const selisih = bestNonSelected 
        ? (1 - bestNonSelected.val / selectedEmissions) * 100 
        : 0;

      // Update insight mode for UI
      if (selisih > 20 && (bestNonSelected?.id === 'bus' || bestNonSelected?.id === 'kereta')) {
        setInsightMode('transport');
      } else {
        setInsightMode('general');
      }

      getAIRecommendation(
        normOrigin, 
        normDest, 
        dist, 
        transport, 
        selectedEmissions, 
        currentlyValidKai,
        bestNonSelected?.id,
        bestNonSelected?.val,
        selisih
      );

      if (window.innerWidth < 1024) {
        setIsMobileFormCollapsed(true);
        // scroll to main content
        setTimeout(() => {
          document.querySelector('main')?.scrollTo({ top: 0, behavior: 'smooth' });
        }, 100);
      }

    } catch (error: any) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  }

  async function getAIRecommendation(
    origin: string, 
    destination: string, 
    dist: number, 
    transport: string, 
    emission: number, 
    isKaiValid: boolean,
    bestMode?: string,
    bestEmission?: number,
    selisihPersen?: number
  ) {
    setAiLoading(true);
    setRecommendation('');

    try {
      let customInstruction = "";
      if (!isKaiValid) {
        if (transport === 'kereta') {
          customInstruction = " Catatan: rute kereta ini tidak tersedia secara nyata. Berikan rekomendasi alternatif transportasi yang realistis untuk rute ini tanpa menyarankan kereta api.";
        } else {
          customInstruction = " Catatan: rute kereta tidak tersedia untuk perjalanan ini, jangan sebut kereta api sebagai alternatif.";
        }
      }

      const response = await fetch('/api/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin,
          destination,
          distance_km: dist,
          transport,
          emission_kg: emission,
          instruction: customInstruction,
          best_mode: bestMode,
          best_emission: bestEmission,
          selisih_persen: selisihPersen,
          language: lang
        })
      });

      const data = await response.json();
      if (response.ok) {
        setRecommendation(data.recommendation || '');
        if (data.is_fallback) {
          setApiStatus('fact_mode');
        } else {
          setApiStatus('connected');
        }
        
        if (data.is_fallback) {
          setInsightMode('fact');
        } else {
          setInsightMode(
            (selisihPersen || 0) > 20 && 
            (bestMode === 'bus' || bestMode === 'kereta')
              ? 'transport'
              : 'general'
          );
        }
      } else {
        setRecommendation(data.message || (lang === 'en' ? "Sorry, AI recommendation could not be loaded. Check API Key configuration." : "Maaf, rekomendasi AI tidak dapat dimuat saat ini. Cek konfigurasi API Key."));
        if (response.status === 429 || response.status === 503) {
          setApiStatus('fact_mode');
        } else {
          setApiStatus('unavailable');
        }
      }
    } catch (error) {
      console.error("AI Fetch Error:", error);
      setRecommendation(lang === 'en' ? "Failed to connect to AI server." : "Gagal terhubung ke server AI.");
      setApiStatus('unavailable');
    } finally {
      setAiLoading(false);
    }
  }

  function handleShare() {
    const shareText = lang === 'en' 
      ? `TripTrace: A trip from ${originDisplayName} → ${destDisplayName} via ${toTitleCase(transport)} produces ${emissions?.toFixed(1)} kg CO₂e. Equivalent to planting ${Math.round((emissions || 0) / 21 * 10) / 10} trees in a year. Check your trace on TripTrace!\n🔗 https://bit.ly/DKTripTrace`
      : `TripTrace: Perjalanan ${originDisplayName} → ${destDisplayName} dengan ${toTitleCase(transport)} menghasilkan ${emissions?.toFixed(1)} kg CO₂e. Setara tanam ${Math.round((emissions || 0) / 21 * 10) / 10} pohon setahun. Cek jejakmu di TripTrace!\n🔗 https://bit.ly/DKTripTrace`;
    
    if (navigator.share) {
      navigator.share({
        title: 'TripTrace Carbon Report',
        text: shareText,
        url: window.location.href
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(shareText);
      setToast(lang === 'en' ? "Text copied to clipboard!" : "Teks berhasil disalin!");
      setTimeout(() => setToast(null), 3000);
    }
  }

  function handleSave() {
    const today = new Date().toLocaleDateString(lang === 'en' ? 'en-US' : 'id-ID', { 
      day: 'numeric', month: 'long', year: 'numeric' 
    });
    
    let content = `=============================
${t.saveTitle}
=============================
${t.saveDate}  : ${today}
${t.saveRoute}     : ${originDisplayName} → ${destDisplayName}
${t.saveDistance}    : ${distance?.toFixed(1)} km
${t.saveMode}     : ${toTitleCase(transport)}
${t.saveEmission}    : ${emissions?.toFixed(2)} kg CO₂e

${t.saveComparison}:
${comparisonData.map(m => `- ${m.name.padEnd(12)} : ${m.val.toFixed(2)} kg CO₂e`).join('\n')}

${t.saveAI}:
${recommendation || (lang === 'en' ? "AI Recommendation not available." : "Saran tidak tersedia.")}

${t.saveFooter}
=============================`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `TripTrace_Report_${originDisplayName}_${destDisplayName}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    setToast(lang === 'en' ? "Report downloaded successfully!" : "Laporan berhasil diunduh!");
    setTimeout(() => setToast(null), 3000);
  }

  const comparisonData = comparisons.length > 0 ? [
    { id: 'pesawat', name: t.plane, val: comparisons.find(c => c.id === 'pesawat')?.val || 0, icon: <Plane className="w-4 h-4" />, isValid: true },
    { id: 'kereta', name: t.train, val: comparisons.find(c => c.id === 'kereta')?.val || 0, icon: <Train className="w-4 h-4" />, isValid: isKaiRouteValid },
    { id: 'mobil', name: t.car, val: comparisons.find(c => c.id === 'mobil')?.val || 0, icon: <Car className="w-4 h-4" />, isValid: true },
    { id: 'motor', name: t.motorcycle, val: comparisons.find(c => c.id === 'motor')?.val || 0, icon: <Bike className="w-4 h-4" />, isValid: true },
    { id: 'bus', name: t.bus, val: comparisons.find(c => c.id === 'bus')?.val || 0, icon: <Bus className="w-4 h-4" />, isValid: true }
  ].sort((a, b) => a.val - b.val).filter(c => c.val > 0) : [];

  const bestChoiceId = comparisonData.find(m => m.isValid)?.id;
  const bestMode = comparisonData.find(m => m.id === bestChoiceId);
  const maxEmis = comparisonData.length > 0 ? Math.max(...comparisonData.map(m => m.val)) : 1;

  return (
    <AnimatePresence mode="wait">
      {showEduPage ? (
        <EduPage key="edu" onBack={() => setShowEduPage(false)} lang={lang} t={t} />
      ) : showHomepage ? (
        <HomePage 
          key="home"
          onStart={() => setShowHomepage(false)}
          onEdu={() => setShowEduPage(true)}
          lang={lang}
          setLang={setLang}
          t={t}
        />
      ) : (
        <motion.div
          key="app"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.4 }}
          className="flex flex-col lg:flex-row h-screen w-full bg-editorial-bg text-slate-900 overflow-hidden font-sans"
        >
          {/* Sticky collapsed bar — hanya tampil di mobile setelah kalkulasi */}
          {isMobileFormCollapsed && (
            <div className="lg:hidden sticky top-0 z-50 bg-white border-b border-slate-100 shadow-sm flex items-center justify-between px-6 h-14 shrink-0">
              <div>
                <p className="text-sm font-medium text-slate-800">
                  {originDisplayName} → {destDisplayName}
                </p>
                <p className="text-xs text-slate-400">{toTitleCase(lang === 'en' ? (transport === 'motor' ? t.motorcycle : transport === 'mobil' ? t.car : transport === 'kereta' ? t.train : transport === 'pesawat' ? t.plane : t.bus) : transport)}</p>
              </div>
              <button 
                onClick={() => {
                  setIsMobileFormCollapsed(false);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="text-xs px-3 py-1.5 border border-slate-200 rounded-full text-slate-600 hover:bg-slate-50 transition-colors"
              >
                {lang === 'en' ? 'Change Route' : 'Ubah Rute'}
              </button>
            </div>
          )}

          {/* Sidebar - Input Controls */}
          <aside className={`w-full lg:w-85 border-b lg:border-b-0 lg:border-r border-slate-200 p-6 lg:p-8 flex-col justify-between bg-white shrink-0 z-40 ${isMobileFormCollapsed ? 'hidden lg:flex' : 'flex'}`}>
            <div className="brand">
              <div className="flex items-center gap-3 mb-6 lg:mb-12">
                <button
                  onClick={() => {
                    setShowHomepage(true);
                    setShowResults(false);
                  }}
                  className="flex items-center gap-2 
                             hover:opacity-70 transition-opacity cursor-pointer">
                  <Leaf className="w-6 h-6 text-brand-green" />
                  <span className="font-bold text-xl text-brand-green">
                    TripTrace
                  </span>
                </button>
                <button
                  onClick={() => setShowEduPage(true)}
                  className="text-xs text-slate-400 hover:text-brand-green transition-colors"
                >
                  {t.aboutCarbon}
                </button>
              </div>

              <div className="space-y-6 lg:space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-1 gap-6">
                  <div className="md:col-span-2 lg:col-span-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-6 lg:gap-8">
                    <div className="relative">
                      <label className="text-[10px] uppercase font-black text-slate-400 tracking-[0.2em] block mb-2">{t.originCity}</label>
                      <div className="relative group">
                        <input 
                          type="text" 
                          value={origin}
                          onChange={(e) => {
                            setOrigin(e.target.value);
                            if (originError) setOriginError('');
                            fetchSuggestions(e.target.value, 'origin');
                            setShowOriginSuggestions(true);
                          }}
                          onKeyDown={(e) => handleKeyDown(e, 'origin')}
                          onFocus={() => origin.length >= 2 && setShowOriginSuggestions(true)}
                          onBlur={() => setTimeout(() => setShowOriginSuggestions(false), 250)}
                          placeholder="Jakarta" 
                          className={`input-field font-bold text-base w-full py-2 transition-all ${originError ? 'border-red-500 bg-red-50/10 focus:border-red-500' : 'focus:border-brand-green'}`}
                        />
                        {originError && (
                          <p className="mt-1.5 text-[10px] font-bold text-red-500 uppercase tracking-wider items-center flex gap-1 animate-in fade-in slide-in-from-top-1">
                            <AlertCircle className="w-3 h-3" /> {originError}
                          </p>
                        )}
                        {showOriginSuggestions && (
                          <div className="absolute top-full left-0 right-0 z-[60] mt-1 bg-white border border-slate-100 shadow-2xl rounded-lg overflow-hidden animate-in fade-in slide-in-from-top-1 duration-200">
                            {originSuggestions.length > 0 ? (
                              <ul>
                                {originSuggestions.map((s, idx) => {
                                  const displayName = formatDisplayName(s);
                                  const [main, sub] = displayName.split(', ');
                                  return (
                                    <li 
                                      key={idx}
                                      onMouseDown={(e) => e.preventDefault()} // Prevent blur before click
                                      onClick={() => {
                                        setOrigin(displayName);
                                        setShowOriginSuggestions(false);
                                      }}
                                      onMouseEnter={() => setOriginIndex(idx)}
                                      className={`px-4 py-3 cursor-pointer flex flex-col transition-colors border-b border-slate-50 last:border-0 ${idx === originIndex ? 'bg-slate-50' : 'bg-white'}`}
                                    >
                                      <span className={`text-sm font-bold ${idx === originIndex ? 'text-brand-green' : 'text-slate-800'}`}>{main}</span>
                                      {sub && <span className="text-[10px] text-slate-400 uppercase tracking-wider">{sub}</span>}
                                    </li>
                                  );
                                })}
                              </ul>
                            ) : origin.length >= 2 && (
                              <div className="p-4 text-xs text-slate-400 text-center italic">Kota tidak ditemukan</div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="relative">
                      <label className="text-[10px] uppercase font-black text-slate-400 tracking-[0.2em] block mb-2">{t.destCity}</label>
                      <div className="relative group">
                        <input 
                          type="text" 
                          value={destination}
                          onChange={(e) => {
                            setDestination(e.target.value);
                            if (destError) setDestError('');
                            fetchSuggestions(e.target.value, 'dest');
                            setShowDestSuggestions(true);
                          }}
                          onKeyDown={(e) => handleKeyDown(e, 'dest')}
                          onFocus={() => destination.length >= 2 && setShowDestSuggestions(true)}
                          onBlur={() => setTimeout(() => setShowDestSuggestions(false), 250)}
                          placeholder="Surabaya" 
                          className={`input-field font-bold text-base w-full py-2 transition-all ${destError ? 'border-red-500 bg-red-50/10 focus:border-red-500' : 'focus:border-brand-green'}`}
                        />
                        {destError && (
                          <p className="mt-1.5 text-[10px] font-bold text-red-500 uppercase tracking-wider items-center flex gap-1 animate-in fade-in slide-in-from-top-1">
                            <AlertCircle className="w-3 h-3" /> {destError}
                          </p>
                        )}
                        {showDestSuggestions && (
                          <div className="absolute top-full left-0 right-0 z-[60] mt-1 bg-white border border-slate-100 shadow-2xl rounded-lg overflow-hidden animate-in fade-in slide-in-from-top-1 duration-200">
                            {destSuggestions.length > 0 ? (
                              <ul>
                                {destSuggestions.map((s, idx) => {
                                  const displayName = formatDisplayName(s);
                                  const [main, sub] = displayName.split(', ');
                                  return (
                                    <li 
                                      key={idx}
                                      onMouseDown={(e) => e.preventDefault()}
                                      onClick={() => {
                                        setDestination(displayName);
                                        setShowDestSuggestions(false);
                                      }}
                                      onMouseEnter={() => setDestIndex(idx)}
                                      className={`px-4 py-3 cursor-pointer flex flex-col transition-colors border-b border-slate-50 last:border-0 ${idx === destIndex ? 'bg-slate-50' : 'bg-white'}`}
                                    >
                                      <span className={`text-sm font-bold ${idx === destIndex ? 'text-brand-green' : 'text-slate-800'}`}>{main}</span>
                                      {sub && <span className="text-[10px] text-slate-400 uppercase tracking-wider">{sub}</span>}
                                    </li>
                                  );
                                })}
                              </ul>
                            ) : destination.length >= 2 && (
                               <div className="p-4 text-xs text-slate-400 text-center italic">{lang === 'en' ? 'City not found' : 'Kota tidak ditemukan'}</div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col md:flex-row lg:flex-col gap-6">
                    <div className="flex-1">
                      <label className="text-[10px] uppercase font-bold text-slate-400 tracking-widest block mb-1">{t.transport}</label>
                      <select 
                        value={transport}
                        onChange={(e) => setTransport(e.target.value)}
                        className="input-field font-semibold text-sm bg-transparent cursor-pointer"
                      >
                        <option value="pesawat">{t.plane}</option>
                        <option value="kereta">{t.train}</option>
                        <option value="mobil">{t.car}</option>
                        <option value="motor">{t.motorcycle}</option>
                        <option value="bus">{t.bus}</option>
                      </select>
                    </div>

                    {transport === 'mobil' && (
                      <div className="flex-1">
                        <label className="text-[10px] uppercase font-bold text-slate-400 tracking-widest block mb-1">{t.passengers}</label>
                        <input 
                          type="number" 
                          value={pax}
                          onChange={(e) => setPax(parseInt(e.target.value))}
                          min="1" 
                          max="6" 
                          className="input-field font-semibold text-sm"
                        />
                      </div>
                    )}
                  </div>
                </div>

                <button 
                  onClick={handleCalculate}
                  disabled={loading}
                  className="w-full py-4 bg-brand-green text-white font-bold tracking-[0.2em] text-[10px] uppercase hover:bg-emerald-700 transition-all active:scale-[0.98] disabled:bg-slate-300 flex justify-center items-center gap-2"
                >
                  {loading ? (
                    <>
                      <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>{loadingText}</span>
                    </>
                  ) : (
                    <span>{t.calculate}</span>
                  )}
                </button>
              </div>
            </div>

            <div className="hidden lg:block footer-info">
            </div>
          </aside>
          
          {/* Main content logic continues... */}

      {/* Main Content */}
      <main className="flex-1 flex flex-col p-6 md:p-8 lg:p-12 relative overflow-y-auto">
        <header className="flex flex-col md:flex-row justify-between items-start mb-8 lg:mb-12 shrink-0 gap-4 md:gap-0">
          <div className="max-w-md">
            <div className="accent-line"></div>
            <h2 className="font-serif text-3xl md:text-4xl mb-4 italic tracking-tight">{t.appTagline}</h2>
            <p className="text-slate-500 text-sm leading-relaxed max-w-sm">
              {t.footerNote}
            </p>
            {/* Status API under heading on mobile */}
            <div className="mt-4 md:hidden">
              <ApiStatusBadge status={apiStatus} lang={lang} t={t} />
            </div>
          </div>
          <div className="hidden md:block text-right">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-300 mb-1">{t.sessionStatus}</p>
            <ApiStatusBadge status={apiStatus} lang={lang} t={t} />
          </div>
        </header>

        <section className="flex-1 flex flex-col min-h-0">
            <AnimatePresence mode="wait">
              {!showResults ? (
                <motion.div 
                  key="welcome"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="h-full flex flex-col items-center justify-center text-center p-12 border-2 border-dashed border-slate-200 rounded-3xl"
                >
                  <p className="text-[80px] font-serif font-bold text-slate-100 leading-none select-none">?</p>
                  
                  <p className="text-base font-serif italic text-slate-400 mt-4">
                    kg CO₂e
                  </p>
                  
                  <p className="text-sm text-slate-400 mt-6 max-w-xs leading-relaxed">
                    {lang === 'en' ? 'Enter your travel route on the left to see how much carbon footprint you will produce.' : 'Masukkan rute perjalananmu di sebelah kiri untuk melihat berapa jejak karbon yang akan kamu hasilkan.'}
                  </p>

                  <div className="flex flex-wrap gap-2 justify-center mt-6">
                    <span className="text-[10px] bg-slate-100 text-slate-400 px-3 py-1 rounded-full whitespace-nowrap">{t.plane}</span>
                    <span className="text-[10px] bg-slate-100 text-slate-400 px-3 py-1 rounded-full whitespace-nowrap">{t.train}</span>
                    <span className="text-[10px] bg-slate-100 text-slate-400 px-3 py-1 rounded-full whitespace-nowrap">{t.car}</span>
                    <span className="text-[10px] bg-slate-100 text-slate-400 px-3 py-1 rounded-full whitespace-nowrap">{t.motorcycle}</span>
                    <span className="text-[10px] bg-slate-100 text-slate-400 px-3 py-1 rounded-full whitespace-nowrap">{t.bus}</span>
                  </div>
                </motion.div>
              ) : (
              <motion.div 
                key="results"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 flex-1 min-h-0"
              >
                {/* Left side: Stats */}
                <div className="md:col-span-1 lg:col-span-7 flex flex-col justify-center py-6">
                  {warnings.length > 0 && (
                    <div className="mb-6 bg-amber-50 border-l-[3px] border-amber-400 p-4 rounded-r-xl flex items-start gap-3 shadow-sm">
                      <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                      <div className="space-y-2">
                        {warnings.map((w, i) => (
                          <p key={i} className="text-sm text-amber-900 font-medium leading-relaxed">
                            {w}
                          </p>
                        ))}
                      </div>
                    </div>
                  )}
                  {kaiStatus && kaiStatus.type === 'success' && (
                    <div className="mb-6 p-4 rounded-xl flex items-start gap-3 border bg-emerald-50 border-emerald-100 text-emerald-800">
                      <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                      <p className="text-xs font-medium leading-relaxed">
                        {kaiStatus.message}
                      </p>
                    </div>
                  )}
                  <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400 mb-2">{t.totalCarbon}</p>
                  <div className="flex items-baseline mb-4">
                    <span className="text-7xl lg:text-[10rem] leading-[0.8] font-bold font-serif text-brand-green tracking-tighter">
                      {emissions?.toFixed(1)}
                    </span>
                    <span className="text-xl md:text-2xl font-light text-slate-400 ml-4 font-serif italic">kg CO₂e</span>
                  </div>

                  {tripLegs.length > 1 && (
                    <div className="mb-8">
                      <p className="text-[9px] uppercase font-black text-slate-400 tracking-[0.3em] mb-3 ml-1">{t.tripDetails2}</p>
                      <div className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden">
                        <div className="divide-y divide-slate-200 divide-dashed">
                          {tripLegs.map((leg, i) => (
                            <div key={i} className="p-4 flex items-center gap-4">
                              <div className="w-8 h-8 rounded-full bg-white border border-slate-100 flex items-center justify-center text-brand-green shadow-sm shrink-0">
                                {leg.icon}
                              </div>
                              <div className="flex-1">
                                <p className="text-sm font-bold text-slate-700 leading-tight">{lang === 'en' ? 'Leg' : 'Bagian'} {i + 1}: {leg.desc}</p>
                                <p className="text-[10px] text-slate-400 font-medium mt-1 uppercase tracking-wider">
                                  {leg.dist.toFixed(1)} km {leg.isEstimated && (lang === 'en' ? "(estimated)" : "(estimasi)")} · <span className="text-slate-600 font-bold">{leg.emis.toFixed(1)} kg CO₂e</span>
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="bg-slate-100/50 p-4 border-t border-slate-300 flex justify-between items-center">
                          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">{t.totalEmission}</span>
                          <span className="text-base font-black text-brand-green">{emissions?.toFixed(1)} kg CO₂e</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {transport === 'kereta' && !isKaiRouteValid && (
                    <div className="mb-8 p-4 bg-slate-50 border border-slate-200 rounded-xl">
                      <div className="flex items-start gap-3">
                        <Train className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium text-slate-700 leading-tight">
                            {t.ifRouteExisted} ({originDisplayName} → {destDisplayName})
                          </p>
                          {(() => {
                            const bestRealModa = [
                              { id: 'bus', val: FACTORS.bus * (distance || 0) },
                              { id: 'motor', val: FACTORS.motor * (distance || 0) },
                              { id: 'mobil', val: FACTORS.mobil * (distance || 0) },
                              { id: 'pesawat', val: FACTORS.pesawat * (distance || 0) }
                            ].sort((a, b) => a.val - b.val)[0];

                            const saving = Math.round((1 - (FACTORS.kereta / FACTORS[bestRealModa.id as keyof typeof FACTORS])) * 100);
                            const modaName = bestRealModa.id === 'bus' ? t.bus : bestRealModa.id === 'motor' ? t.motorcycle : bestRealModa.id === 'mobil' ? t.car : t.plane;

                            return (
                              <p className="text-xs text-slate-500 italic mt-2 leading-relaxed">
                                {lang === 'en' 
                                  ? `If this route existed one day, your trip would only produce ${emissions?.toFixed(1)} kg CO₂e — ${saving}% more efficient than ${modaName}.`
                                  : `Kalau suatu hari jalur ini ada, perjalananmu hanya akan menghasilkan ${emissions?.toFixed(1)} kg CO₂e — ${saving}% lebih hemat dari ${modaName}.`
                                }
                              </p>
                            );
                          })()}
                        </div>
                      </div>
                    </div>
                  )}

                  {distance && (
                    <p className="text-xs text-slate-400 mt-4 font-medium uppercase tracking-widest pl-2 border-l border-slate-200">
                      {t.tripRoute}: {originDisplayName} → {destDisplayName} ({distance.toFixed(1)} km)
                    </p>
                  )}

                  {mapLegs.length > 0 && (
                    <div className="mt-8 mb-4">
                      <p className="text-[9px] uppercase tracking-widest text-slate-400 mb-2">
                        {t.routeViz}
                      </p>
                      {mapLoading ? (
                        <div className="w-full h-64 lg:h-80 rounded-2xl border border-slate-200 bg-slate-50 flex items-center justify-center">
                          <div className="flex flex-col items-center gap-2">
                            <div className="w-5 h-5 border-2 border-slate-200 border-t-brand-green rounded-full animate-spin"/>
                            <p className="text-xs text-slate-400">
                              {lang === 'en' ? 'Loading route...' : 'Memuat rute...'}
                            </p>
                          </div>
                        </div>
                      ) : (
                        <MapView legs={mapLegs} visible={showResults} t={t} />
                      )}
                      {!mapLoading && (
                        <div className="flex gap-4 mt-2 px-1">
                          <div className="flex items-center gap-1.5">
                            <div className="w-6 h-0.5 bg-emerald-500"/>
                            <span className="text-[10px] text-slate-400">{t.mapLegendLand}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <div className="w-6 h-0.5 border-t-2 border-dashed border-blue-500"/>
                            <span className="text-[10px] text-slate-400">{t.mapLegendFerry}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <div className="w-6 h-0.5 border-t-2 border-dotted border-violet-500"/>
                            <span className="text-[10px] text-slate-400">{t.mapLegendFlight}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="mt-12 lg:mt-16 grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4 items-stretch">
                    <ComparisonCard 
                      icon={<Fuel className="w-5 h-5 text-blue-500" />}
                      label={t.fuelCard}
                      framing={transport === 'motor' 
                        ? (lang === 'en' ? "Estimated how many times you refuel" : "Perkiraan berapa kali kamu isi bensin")
                        : t.fuelSub
                      }
                      value={transport === 'motor' 
                        ? Math.ceil((emissions || 0) / 2.31 / 5.5)
                        : Math.round((emissions || 0) / 2.31)
                      }
                      unit={transport === 'motor' ? (lang === 'en' ? "TIMES" : "KALI ISI") : "Liter"}
                      context={transport === 'motor'
                        ? (lang === 'en' ? `Or about ${Math.round((emissions || 0) / 2.31)} liters of fuel total for the trip` : `Atau sekitar ${Math.round((emissions || 0) / 2.31)} liter total Pertalite sepanjang perjalanan`)
                        : `${t.fuelContext}\n${Math.round((emissions || 0) / 2.31 * 45)} km`
                      }
                    />
                    <ComparisonCard 
                      icon={<Trees className="w-5 h-5 text-emerald-500" />}
                      label={t.treeCard}
                      framing={t.treeSub}
                      value={((emissions || 0) / 21).toFixed(1)}
                      unit={lang === 'en' ? "Years" : "Tahun"}
                      context={((emissions || 0) / 21) > 1 
                        ? `${t.treeContext1} ${Math.ceil((emissions || 0) / 21)} ${t.treeContext2}`
                        : (lang === 'en' ? `Needs ${Math.ceil((emissions || 0) / 21 * 12)} months` : `Butuh ${Math.ceil((emissions || 0) / 21 * 12)} bulan`)
                      }
                    />
                    <ComparisonCard 
                      icon={<ShoppingBag className="w-5 h-5 text-amber-500" />}
                      label={t.plasticCard}
                      framing={t.plasticSub}
                      value={Math.round((emissions || 0) / 0.006).toLocaleString(lang === 'en' ? 'en-US' : 'id-ID')}
                      unit={lang === 'en' ? "Bags" : "Kantong"}
                      context={t.plasticContext}
                    />
                  </div>
                </div>

                {/* Right side: Insights & Comparisons */}
                <div className="md:col-span-1 lg:col-span-5 flex flex-col justify-end space-y-8 py-6">
                  {/* AI Insight Box */}
                  <div className="p-6 lg:p-8 bg-white border border-slate-100 border-l-2 border-l-emerald-400 shadow-xl shadow-slate-200/50 rounded-lg relative group">
                      <div className="absolute -top-4 -left-4 p-3 bg-brand-green text-white shadow-lg rounded-sm transform group-hover:rotate-6 transition-transform">
                        {insightMode === 'general' || insightMode === 'fact'
                          ? <Sparkles className="w-5 h-5" />
                          : <Navigation className="w-5 h-5" />
                        }
                      </div>
                      <h3 className="font-bold text-slate-800 mb-4 text-sm flex items-center gap-2">
                        {insightMode === 'general' && (lang === 'en' ? '✦ Insight from Gemini' : '✦ Insight dari Gemini')}
                        {insightMode === 'transport' && (lang === 'en' 
                          ? `Alternative ${toTitleCase(bestMode?.id || '')} for This Route` 
                          : `Alternatif ${toTitleCase(bestMode?.id || '')} untuk Rute Ini`)}
                        {insightMode === 'fact' && (lang === 'en' ? '✦ Did You Know?' : '✦ Tahukah Kamu?')}
                      </h3>
                      
                      {aiLoading ? (
                        <div className="space-y-3 py-2">
                          <div className="h-3 bg-slate-100 rounded animate-pulse w-full"></div>
                          <div className="h-3 bg-slate-100 rounded animate-pulse w-5/6"></div>
                          <div className="h-3 bg-slate-100 rounded animate-pulse w-4/6"></div>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <p className={`text-sm text-slate-700 leading-relaxed ${!expanded ? 'line-clamp-6' : ''}`}>
                            {recommendation || (lang === 'en' ? "Recommendation is being prepared..." : "Rekomendasi sedang disiapkan...")}
                          </p>
                          {recommendation && recommendation.length > 300 && (
                            <button 
                              onClick={() => setExpanded(!expanded)}
                              className="text-[10px] text-emerald-600 underline mt-1 hover:no-underline"
                            >
                              {expanded ? t.close : t.readMore}
                            </button>
                          )}
                          {insightMode === 'fact' && (
                            <p className="text-[9px] italic text-slate-300 mt-3">
                              Fakta karbon · AI insight tidak tersedia saat ini
                            </p>
                          )}
                        </div>
                      )}

                      <div className="mt-8 pt-6 border-t border-slate-50 flex justify-between items-center font-sans">
                        <span className="text-[10px] uppercase tracking-widest text-emerald-600 font-medium italic">✦ {lang === 'en' ? 'Insight from Gemini' : 'Insight dari Gemini'}</span>
                        <div className="flex gap-3">
                          <button onClick={handleShare}
                            className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-emerald-600 transition-colors">
                            <Share2 className="w-3 h-3" />
                            {t.share}
                          </button>
                          <button onClick={handleSave}
                            className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-emerald-600 transition-colors">
                            <Download className="w-3 h-3" />
                            {t.save}
                          </button>
                        </div>
                      </div>
                  </div>

                  {/* Next Step Card */}
                  {(() => {
                    const bestMode = comparisonData.find(m => m.id === bestChoiceId);
                    if (!bestMode || !emissions) return null;

                    const diffFromBest = (1 - bestMode.val / emissions);
                    
                    // Cond 3: Pesawat vs Kereta (Specific Factoid)
                    if (transport === 'pesawat' && isKaiRouteValid && bestChoiceId === 'kereta') {
                      return (
                        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm">
                          <h3 className="text-sm font-semibold text-slate-800">{lang === 'en' ? 'Did you know? ✈️' : 'Tahukah kamu? ✈️'}</h3>
                          <p className="text-sm text-slate-500 leading-relaxed mt-1">
                            {lang === 'en' 
                              ? `Flights produce emissions ${Math.round((emissions - bestMode.val) / bestMode.val)}x larger than trains for the same distance. If your time is flexible, trains can be a much better choice for the earth.`
                              : `Penerbangan menghasilkan emisi ${Math.round((emissions - bestMode.val) / bestMode.val)}x lebih besar dari kereta untuk jarak yang sama. Kalau waktumu fleksibel, kereta bisa jadi pilihan yang jauh lebih baik untuk bumi.`
                            }
                          </p>
                          {insightMode === 'transport' ? (
                            <p className="mt-4 text-[10px] italic text-slate-400">{t.seeAbove}</p>
                          ) : (
                            <button 
                              onClick={() => {
                                setInsightMode('transport');
                                getAIRecommendation(originDisplayName, destDisplayName, distance!, transport, emissions!, isKaiRouteValid, bestMode.id, bestMode.val, (1 - bestMode.val / emissions!) * 100);
                              }}
                              className="mt-4 inline-flex items-center gap-2 text-[10px] font-bold bg-brand-green text-white px-4 py-2 rounded-full hover:bg-opacity-90 transition"
                            >
                              {t.trainCTA}
                            </button>
                          )}
                        </div>
                      );
                    }

                    // Cond 1: Not the best & diff > 20%
                    if (transport !== bestChoiceId && diffFromBest > 0.2) {
                      if (bestChoiceId === 'kereta' && isKaiRouteValid) {
                         return (
                          <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm">
                            <h3 className="text-sm font-semibold text-slate-800">{t.greenerOption}</h3>
                            <p className="text-sm text-slate-500 leading-relaxed mt-1">
                              {lang === 'en'
                                ? `Train for this route produces ${bestMode.val.toFixed(1)} kg CO₂e — ${Math.round(diffFromBest * 100)}% lower than your choice.`
                                : `Kereta api untuk rute ini menghasilkan ${bestMode.val.toFixed(1)} kg CO₂e — ${Math.round(diffFromBest * 100)}% lebih rendah dari pilihanmu.`
                              }
                            </p>
                            {insightMode === 'transport' ? (
                              <p className="mt-4 text-[10px] italic text-slate-400">{t.seeAbove}</p>
                            ) : (
                              <button 
                                onClick={() => {
                                  setInsightMode('transport');
                                  getAIRecommendation(originDisplayName, destDisplayName, distance!, transport, emissions!, isKaiRouteValid, bestMode.id, bestMode.val, (1 - bestMode.val / emissions!) * 100);
                                }}
                                className="mt-4 inline-flex items-center gap-2 text-[10px] font-bold bg-brand-green text-white px-4 py-2 rounded-full hover:bg-opacity-90 transition"
                              >
                                {t.trainCTA}
                              </button>
                            )}
                          </div>
                        );
                      }
                      if (bestChoiceId === 'bus') {
                        return (
                          <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm">
                            <h3 className="text-sm font-semibold text-slate-800">{t.greenerOption}</h3>
                            <p className="text-sm text-slate-500 leading-relaxed mt-1">
                              {lang === 'en'
                                ? `Bus for this route produces ${bestMode.val.toFixed(1)} kg CO₂e — ${Math.round(diffFromBest * 100)}% lower than your choice.`
                                : `Bus untuk rute ini menghasilkan ${bestMode.val.toFixed(1)} kg CO₂e — ${Math.round(diffFromBest * 100)}% lebih rendah dari pilihanmu.`
                              }
                            </p>
                            {insightMode === 'transport' ? (
                              <p className="mt-4 text-[10px] italic text-slate-400">{t.seeAbove}</p>
                            ) : (
                              <button 
                                onClick={() => {
                                  setInsightMode('transport');
                                  getAIRecommendation(originDisplayName, destDisplayName, distance!, transport, emissions!, isKaiRouteValid, bestMode.id, bestMode.val, (1 - bestMode.val / emissions!) * 100);
                                }}
                                className="mt-4 inline-flex items-center gap-2 text-[10px] font-bold bg-brand-green text-white px-4 py-2 rounded-full hover:bg-opacity-90 transition"
                              >
                                {t.busCTA}
                              </button>
                            )}
                          </div>
                        );
                      }
                    }

                    // Cond 2: Is the best
                    if (transport === bestChoiceId) {
                      return (
                        <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-xl shadow-sm">
                          <h3 className="text-sm font-semibold text-slate-800">{t.bestChoice}</h3>
                          <p className="text-sm text-slate-500 leading-relaxed mt-1">
                            {t.alreadyBest}
                          </p>
                        </div>
                      );
                    }

                    return null;
                  })()}


                  {/* Comparison List */}
                  <div className="bg-white/50 backdrop-blur-sm rounded-2xl border border-slate-200/50 overflow-hidden font-sans">
                    <div className="px-6 py-3 bg-slate-50/50 border-b border-slate-200/50">
                      <p className="text-[8px] font-black uppercase tracking-[0.3em] text-slate-400 font-sans">{t.efficiency}</p>
                    </div>
                    <div className="divide-y divide-slate-100">
                      {comparisonData.map((m, idx) => (
                        <div key={m.id} className={`flex items-center justify-between px-6 py-4 transition-all ${transport === m.id ? 'bg-emerald-50/50 border-l-[3px] border-emerald-500' : ''} ${!m.isValid ? 'opacity-50' : ''}`}>
                          <div className="flex items-center gap-4 flex-1">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${transport === m.id ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-50 text-slate-400'} ${m.id === 'kereta' && !m.isValid ? 'relative overflow-hidden' : ''}`}>
                              {m.icon}
                              {m.id === 'kereta' && !m.isValid && (
                                <div className="absolute inset-0 flex items-center justify-center opacity-20 rotate-45">
                                  <div className="w-full h-[1px] bg-slate-900"></div>
                                </div>
                              )}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <p className={`text-xs font-bold ${transport === m.id ? 'text-emerald-900' : !m.isValid ? 'text-slate-300' : 'text-slate-600'}`}>
                                  {m.id === 'pesawat' ? t.plane : m.id === 'kereta' ? t.train : m.id === 'mobil' ? t.car : m.id === 'motor' ? t.motorcycle : t.bus}
                                </p>
                                {transport === m.id && (
                                  <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-600 text-[7px] font-black uppercase rounded">{t.yourChoice}</span>
                                )}
                                {m.id === bestChoiceId && (
                                  <span className="px-1.5 py-0.5 bg-brand-green/10 text-brand-green text-[7px] font-black uppercase rounded">{t.bestMode}</span>
                                )}
                                {m.id === 'kereta' && !m.isValid && (
                                  <span className="text-[7px] font-bold text-slate-300 uppercase tracking-wider italic">{t.routeUnavailable}</span>
                                )}
                              </div>
                              {/* Progress bar */}
                              <div className="w-full max-w-[120px] h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                <motion.div 
                                  initial={{ width: 0 }}
                                  animate={{ width: `${(m.val / (maxEmis || 1)) * 100}%` }}
                                  className={`h-full ${m.id === bestChoiceId ? 'bg-emerald-400' : idx === comparisonData.length -1 ? 'bg-red-400' : 'bg-slate-300'}`}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className={`text-sm font-black ${transport === m.id ? 'text-emerald-900' : !m.isValid ? 'text-slate-300' : 'text-slate-900'}`}>
                              {m.val.toFixed(1)} <span className="text-[10px] font-bold text-slate-400">kg</span>
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Consolidated Footnote */}
                  <div className="lg:col-span-12 pt-8 border-t border-slate-100/50">
                    <p className="text-[9px] italic text-slate-300 text-center lg:text-left leading-relaxed">
                      {t.footerNote}
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>

      </main>

      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: 50, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 50, x: '-50%' }}
            className="fixed bottom-8 left-1/2 z-[100] px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-full shadow-2xl flex items-center gap-2"
          >
            <CheckCircle className="w-3 h-3 text-emerald-400" />
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
      )}
    </AnimatePresence>
  );
}

