import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import cors from "cors";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

let aiInstance: GoogleGenAI | null = null;

// Prototype bridge to support requested getGenerativeModel syntax
(GoogleGenAI.prototype as any).getGenerativeModel = function (options: { model: string }) {
  const self = this;
  return {
    generateContent: async (prompt: string) => {
      const response = await self.models.generateContent({
        model: options.model,
        contents: prompt
      });
      return {
        response: {
          text: () => response.text || ''
        }
      };
    }
  };
};

function getAI(): any {
  if (!aiInstance) {
    const apiKey = 
      process.env.GEMINI_API_KEY ||
      process.env.GOOGLE_API_KEY ||
      process.env.API_KEY;

    if (!apiKey || 
        apiKey === 'MY_GEMINI_API_KEY' || 
        apiKey.trim() === '') {
      throw new Error(
        'Gemini API Key is missing or invalid. ' +
        'Please configure it in the Secrets panel.'
      );
    }

    aiInstance = new GoogleGenAI({ 
      apiKey,
      httpOptions: {
        headers: { 'User-Agent': 'aistudio-build' }
      }
    });
  }
  return aiInstance;
}

async function callGeminiWithRetry(
  ai: any,
  prompt: string,
  modelName: string,
  maxRetries = 3
): Promise<string> {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const model = ai.getGenerativeModel({ 
        model: modelName 
      });
      const result = await model.generateContent(prompt);
      return result.response.text() || '';
    } catch (err: any) {
      console.warn(`Gemini attempt ${attempt} failed:`, 
        err?.message?.slice(0, 100));
      
      if (attempt === maxRetries) throw err;
      
      const is429 = err?.message?.includes('429') ||
                    err?.message?.includes('RESOURCE_EXHAUSTED');
      
      const delay = is429 ? 5000 : attempt * 1000;
      await new Promise(r => setTimeout(r, delay));
    }
  }
  throw new Error('Max retries exceeded');
}

const CARBON_FACTS = [
  "Tahukah kamu? Kereta api menghasilkan emisi 7x lebih rendah dibanding pesawat untuk jarak yang sama. Pilihan moda transportasi adalah salah satu keputusan iklim terbesar yang bisa kamu buat sehari-hari.",
  "Satu pohon dewasa menyerap sekitar 21 kg CO₂ per tahun. Artinya, untuk menetralisir emisi 1 penerbangan domestik Indonesia (~92 kg CO₂), dibutuhkan sekitar 4-5 pohon selama setahun penuh.",
  "Indonesia adalah negara kepulauan terbesar di dunia — dan itu membuat pilihan transportasi kita lebih kompleks dan berdampak dari rata-rata negara lain. Setiap keputusan moda perjalanan antar pulau punya jejak yang nyata.",
  "Emisi dari sektor transportasi menyumbang sekitar 16% dari total emisi gas rumah kaca global. Di Indonesia, angka ini terus naik seiring pertumbuhan kepemilikan kendaraan pribadi.",
  "Kalau semua penumpang rute Jakarta-Surabaya beralih dari pesawat ke kereta dalam setahun, penghematan emisinya setara dengan menanam lebih dari 2 juta pohon.",
  "CO₂ yang kamu lepas hari ini akan tetap ada di atmosfer selama 300-1000 tahun. Emisi karbon bukan masalah hari ini — tapi warisan untuk generasi yang belum lahir.",
  "Bus adalah moda transportasi darat paling efisien secara emisi per penumpang untuk jarak jauh — bahkan lebih rendah dari kereta untuk rute tertentu. Sayangnya sering diabaikan karena dianggap tidak praktis.",
  "Rata-rata orang Indonesia menghasilkan 2.1 ton CO₂e per tahun — jauh di bawah rata-rata global 4.7 ton. Tapi dengan pertumbuhan ekonomi dan mobilitas, angka ini diprediksi terus naik.",
  "Penyeberangan feri Merak-Bakauheni adalah salah satu rute feri tersibuk di dunia — dengan ribuan kendaraan menyeberang setiap hari. Beralih ke bus daripada membawa mobil pribadi bisa memotong emisi perjalanan hingga 60%.",
  "Emisi pesawat sebenarnya lebih kompleks dari angka CO₂-nya saja — efek contrail dan cirrus clouds dari penerbangan bisa melipatgandakan dampak pemanasan globalnya hingga 2-4 kali lipat.",
];

function getRandomCarbonFact(): string {
  const idx = Math.floor(Math.random() * CARBON_FACTS.length);
  return CARBON_FACTS[idx];
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  const allowedOrigins = [
    'http://localhost:3000',
    'http://localhost:5173',
    process.env.FRONTEND_URL,
    process.env.APP_URL
  ].filter(Boolean);

  app.use(cors({
    origin: (origin, callback) => {
      // Allow requests with no origin (curl, Postman)
      if (!origin) return callback(null, true);
      
      const isAllowed = 
        // Origins yang explicitly diizinkan
        allowedOrigins.some(allowed => origin === allowed) ||
        // Cloud Run domains (harus end with .run.app)
        origin.endsWith('.run.app') ||
        // AI Studio domain spesifik (exact match)
        origin === 'https://aistudio.google.com' ||
        origin === 'https://ai.google.dev' ||
        // Localhost untuk development
        origin.startsWith('http://localhost:') ||
        origin.startsWith('http://127.0.0.1:');

      if (isAllowed) {
        return callback(null, true);
      }
      
      console.warn(`CORS blocked for origin: ${origin}`);
      callback(new Error('Not allowed by CORS'));
    },
    credentials: true
  }));
  app.use(express.json({ limit: '10kb' }));
  app.use(express.urlencoded({ 
    extended: false, 
    limit: '10kb' 
  }));

  app.use((req, res, next) => {
    // Prevent clickjacking
    res.setHeader('X-Frame-Options', 'DENY');
    // Prevent MIME sniffing
    res.setHeader('X-Content-Type-Options', 'nosniff');
    // XSS protection (legacy browsers)
    res.setHeader('X-XSS-Protection', '1; mode=block');
    // Referrer policy
    res.setHeader('Referrer-Policy', 
      'strict-origin-when-cross-origin');
    next();
  });

  // Taruh di atas startServer(), sejajar dengan searchCache
  const recommendRateLimit = new Map<string, { count: number, resetAt: number }>();
  const RECOMMEND_LIMIT = 10;      // max 10 request
  const RECOMMEND_WINDOW = 60_000; // per 60 detik per IP

  const searchRateLimit = new Map<string, { 
    count: number, resetAt: number 
  }>();
  const SEARCH_LIMIT = 30;       // max 30 request
  const SEARCH_WINDOW = 60_000;  // per 60 detik per IP

  // Bersihkan map setiap 5 menit agar tidak memory leak
  setInterval(() => {
    const now = Date.now();
    for (const [key, val] of recommendRateLimit.entries()) {
      if (now > val.resetAt) recommendRateLimit.delete(key);
    }
    // Tambahkan ini:
    for (const [key, val] of searchRateLimit.entries()) {
      if (now > val.resetAt) searchRateLimit.delete(key);
    }
  }, 5 * 60 * 1000);

  // API Route for recommendations
  app.post("/api/recommend", async (req, res) => {
    try {
      const ip = req.ip || req.socket.remoteAddress || 'unknown';
      const now = Date.now();
      const rl = recommendRateLimit.get(ip);

      if (rl && now < rl.resetAt) {
        if (rl.count >= RECOMMEND_LIMIT) {
          return res.status(429).json({ 
            error: 'Terlalu banyak permintaan. Coba lagi dalam 1 menit.' 
          });
        }
        rl.count++;
      } else {
        recommendRateLimit.set(ip, { count: 1, resetAt: now + RECOMMEND_WINDOW });
      }

      const { origin, destination, distance_km, transport, emission_kg, instruction, best_mode, best_emission, selisih_persen, language } = req.body;

      // Validasi tipe dan panjang
      if (typeof origin !== 'string' || origin.length > 100) {
        return res.status(400).json({ error: 'Input origin tidak valid' });
      }
      if (typeof destination !== 'string' || destination.length > 100) {
        return res.status(400).json({ error: 'Input destination tidak valid' });
      }
      if (typeof distance_km !== 'number' || distance_km <= 0 || distance_km > 10000) {
        return res.status(400).json({ error: 'Jarak tidak valid' });
      }
      if (typeof emission_kg !== 'number' || emission_kg < 0) {
        return res.status(400).json({ error: 'Emisi tidak valid' });
      }

      const VALID_TRANSPORTS = ['pesawat','kereta','mobil','motor','bus'];
      if (!VALID_TRANSPORTS.includes(transport)) {
        return res.status(400).json({ error: 'Moda transportasi tidak valid' });
      }

      // Sanitasi: strip karakter berbahaya dari string fields
      const sanitize = (str: string) => 
        str.replace(/[<>{}|\\^`]/g, '').trim();

      const safeOrigin = sanitize(origin);
      const safeDestination = sanitize(destination);

      // Batasi instruction (dari internal app, bukan user input langsung)
      // tapi tetap limit panjangnya
      const safeInstruction = typeof instruction === 'string' 
        ? sanitize(instruction).slice(0, 300) 
        : '';

      const languageInstruction = language === 'en'
        ? 'Respond in English. Keep it casual and friendly.'
        : 'Jawab dalam Bahasa Indonesia. Tone casual dan friendly.';

      const ai = getAI();
      let prompt = `${languageInstruction} 2-3 kalimat casual tentang perjalanan ${safeOrigin}→${safeDestination} naik ${transport} (${emission_kg.toFixed(1)}kg CO₂e, ${distance_km.toFixed(0)}km). Saran alternatif lokal yang relevan. Tidak menghakimi. ${safeInstruction}`;

      if (best_mode && typeof best_mode === 'string' && selisih_persen && selisih_persen > 20) {
        prompt += language === 'en'
          ? ` Also mention in 1 sentence practical info about ${sanitize(best_mode)} for this route: general operators or how to find them.`
          : ` Juga sebutkan 1 kalimat info praktis tentang ${sanitize(best_mode)} untuk rute ini: operator umum atau cara mencarinya.`;
      }

      const modelName = "gemini-3-flash-preview";
      const text = await callGeminiWithRetry(ai, prompt, modelName);

      res.json({ recommendation: text });
    } catch (error: any) {
      console.error("Internal error:", error);
      
      const isKeyError = error.message?.includes("API key") || 
                         error.message?.includes("Secrets panel");
      
      if (!isKeyError) {
        return res.json({ 
          recommendation: getRandomCarbonFact(),
          is_fallback: true
        });
      }
      
      res.status(401).json({ 
        error: "API Key Error." 
      });
    }
  });

  // Simple in-memory cache to prevent 429s
  const searchCache = new Map<string, { data: any, timestamp: number }>();
  const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours
  const MAX_CACHE_SIZE = 500;

  // API Route for location search (Proxy to Nominatim)
  app.get("/api/search", async (req, res) => {
    try {
      const ip = req.ip || req.socket.remoteAddress || 'unknown';
      const now = Date.now();
      const srl = searchRateLimit.get(ip);

      if (srl && now < srl.resetAt) {
        if (srl.count >= SEARCH_LIMIT) {
          return res.status(429).json({ 
            error: 'Terlalu banyak permintaan pencarian.' 
          });
        }
        srl.count++;
      } else {
        searchRateLimit.set(ip, { 
          count: 1, 
          resetAt: now + SEARCH_WINDOW 
        });
      }

      const { q, ...params } = req.query;
      if (!q) return res.status(400).json({ error: "Query required" });

      const searchParams = new URLSearchParams();
      searchParams.append("format", "json");
      searchParams.append("q", q as string);
      searchParams.append("addressdetails", "1");
      
      Object.keys(params).forEach(key => {
        if (params[key]) {
          searchParams.append(key, params[key] as string);
        }
      });

      const cacheKey = searchParams.toString();
      const cached = searchCache.get(cacheKey);

      if (cached && (Date.now() - cached.timestamp < CACHE_TTL)) {
        return res.json(cached.data);
      }

      const response = await fetch(`https://nominatim.openstreetmap.org/search?${searchParams.toString()}`, {
        headers: {
          'User-Agent': 'TripTraceApp/1.0 (contact@triptrace.app)',
          'Accept': 'application/json'
        }
      });
      
      const contentType = response.headers.get("content-type");

      if (response.status === 429) {
        console.error("Nominatim Rate Limit Hit (429)");
        return res.status(429).json({ 
          error: "Terlalu banyak permintaan ke layanan peta.", 
          retryAfter: response.headers.get("retry-after") || "60"
        });
      }

      if (response.ok && contentType && contentType.includes("application/json")) {
        const data = await response.json();
        // Only cache successful city results
        if (Array.isArray(data) && data.length > 0) {
          // Evict oldest entry jika cache penuh
          if (searchCache.size >= MAX_CACHE_SIZE) {
            const firstKey = searchCache.keys().next().value;
            searchCache.delete(firstKey);
          }
          searchCache.set(cacheKey, { data, timestamp: Date.now() });
        }
        res.json(data);
      } else {
        const text = await response.text();
        console.error(`Nominatim Error (${response.status}):`, text.slice(0, 200));
        res.status(response.status || 500).json({ 
          error: "Search failed", 
          details: `Nominatim status ${response.status}`
        });
      }
    } catch (error: any) {
      console.error("Internal error:", error); // log di server saja
      res.status(500).json({ error: "Terjadi kesalahan pada server. Coba beberapa saat lagi." });
    }
  });

  // API Route for OSRM routing
  app.get("/api/route", async (req, res) => {
    try {
      const { coords } = req.query;
      if (!coords || typeof coords !== 'string') {
        return res.status(400).json({ error: "Invalid coordinates" });
      }

      // Validasi format: hanya boleh angka, koma, titik, 
      // titik koma, dan minus
      const coordPattern = /^[-0-9.,;]+$/;
      if (!coordPattern.test(coords)) {
        return res.status(400).json({ 
          error: "Invalid coordinate format" 
        });
      }

      // Batasi panjang
      if (coords.length > 200) {
        return res.status(400).json({ 
          error: "Coordinates too long" 
        });
      }

      const response = await fetch(`https://router.project-osrm.org/route/v1/driving/${coords}?overview=false`, {
        headers: {
          'User-Agent': 'TripTraceApp/1.0 (contact@triptrace.app)',
        }
      });

      if (response.ok) {
        const data = await response.json();
        res.json(data);
      } else {
        res.status(response.status).json({ error: "Routing failed" });
      }
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
